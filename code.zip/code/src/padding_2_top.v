`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/05 15:32:22
// Design Name: 
// Module Name: padding_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module padding_2_top
#( parameter    DATA_WIDTH   = 16,
   parameter    FMAP_SIZE    = 32,
   parameter	PADDING_SIZE = 1 ,
   parameter    channel      = 10, //padding�ߴ�
	parameter   CNT_BIT_NUM  = 6 ,
	parameter   LINE_CNT_BIT_NUM = 6
)
(
   input                       clk,//ʱ��
   input                       rst_n,//�͵�ƽ��λ
   input                       wr_en,//fifoдʹ�ܣ����ڻ���ͼƬ����
   input                       ena,//paddingʹ��(һ����wr_enдʹ��ͬ��)
   input   [DATA_WIDTH -1 :0]  data_in,//д������
   output  [DATA_WIDTH -1 :0]  data_out,//padding������
   output                      valid,//paddingͼ����Ч�źţ���padding����ڼ��øߣ�
   output                      done ,//padding�������źţ�valid��1��0ʱ���һ���ߵ�ƽ���壩
   //data_ram�ӿ�
   output [LINE_CNT_BIT_NUM-1:0] cnt_col ,
   output [LINE_CNT_BIT_NUM-1:0] cnt_row ,
   output [3:0]                  feature_cnt                    
   );
   wire fifo_rd_en;
   wire [DATA_WIDTH-1:0] fifo_out;
   
   
   padding_fifo_2 u_conv_2_fifo (
  .clk(clk),      // input wire clk
  .srst(!rst_n),    // input wire srst
  .din(data_in),      // input wire [15 : 0] din
  .wr_en(wr_en),  // input wire wr_en
  .rd_en(fifo_rd_en),  // input wire rd_en
  .dout(fifo_out),    // output wire [15 : 0] dout
  .full(),    // output wire full
  .empty()  // output wire empty
  );
	
	PADDING_2
	#(
		.DATA_WIDTH(DATA_WIDTH),
		.FMAP_SIZE(FMAP_SIZE),
		.N(PADDING_SIZE),
		.channel(channel),
		.CNT_BIT_NUM(CNT_BIT_NUM),
		.LINE_CNT_BIT_NUM(LINE_CNT_BIT_NUM)
	)
	u_padding
	(
		.clk(clk),
		.rst_n(rst_n),
		.clear(),
		.ena(ena),
		.fmap_raw(fifo_out),
		.fmap_pad(data_out),
		.rd_en(fifo_rd_en),
		.valid(valid),
		.done(done),
		.cnt_col_1(cnt_col),
		.cnt_row_1(cnt_row),
		.feature_cnt_1(feature_cnt)
	);
endmodule

module title1(
    input clk,
    input[12:0]addr,
    output title_data
    );
wire[255:0]rom_data;
reg[7:0]col_reg;        
reg[4:0]row_index;  
reg[7:0]col_index;
zxddzdtx rom(
  .clka(clk),    // input wire clka
  .addra(row_index),  // input wire [4 : 0] addra
  .douta(rom_data)  // output wire [255 : 0] douta
);
always @(posedge clk) begin
    row_index<=addr[12:8];
    col_index<=255-addr[7:0];
    // Stage 2: ������������ROM����
    col_reg  <= col_index;
end
assign title_data=rom_data[col_reg];
endmodule

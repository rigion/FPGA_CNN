module FIFO
#(
	parameter DATA_WIDTH = 16,
	parameter BUF_SIZE = 10
)
( 	input clk,
	input rst_n,
	input [DATA_WIDTH-1:0]buf_in,
	input wr_en,
	input rd_en,
	input rd_rewind,
	output fifo_empty,
	output fifo_full,
	output reg [DATA_WIDTH-1:0]buf_out
);
	//find bit width
	function integer clogb2 (input integer bit_depth);
	begin
		for(clogb2=0; bit_depth>0; clogb2=clogb2+1)
		bit_depth = bit_depth >> 1;
	end
	endfunction

	localparam CNT_BIT_NUM = clogb2(BUF_SIZE);
	localparam ALLIGN_BUF_SIZE = 32'b1 << CNT_BIT_NUM;

	reg [CNT_BIT_NUM-1:0] rd_ptr, wr_ptr;
	reg [CNT_BIT_NUM-1:0] fifo_cnt;
	reg [DATA_WIDTH-1:0] buf_mem[ALLIGN_BUF_SIZE-1:0];
	integer i;

	assign fifo_empty = (fifo_cnt == 0); 
	assign fifo_full  = (fifo_cnt == ALLIGN_BUF_SIZE);
	
	always @(posedge clk or negedge rst_n) begin
		if(!rst_n)
			fifo_cnt <= 0;
		else if((!fifo_full && wr_en) && (!fifo_empty && rd_en))
			fifo_cnt <= fifo_cnt;
		else if(!fifo_full && wr_en)     
			fifo_cnt <= fifo_cnt + 1;
		else if(!fifo_empty && rd_en)  
			fifo_cnt <= fifo_cnt-1;
		else 
			fifo_cnt <= fifo_cnt;
	end
	
	always @(posedge clk or negedge rst_n)
	begin
		if(!rst_n)
			buf_out <= 0;
		else if(rd_en && !fifo_empty)
			buf_out <= buf_mem[rd_ptr];
	end
	
	always @(posedge clk or negedge rst_n) begin
		if(!rst_n)
			for(i = 0; i < BUF_SIZE; i = i + 1)
				buf_mem[i] <= 0;
		else if(wr_en && !fifo_full)
			buf_mem[wr_ptr] <= buf_in;
	end
	
	always @(posedge clk or negedge rst_n) 
	begin
		if(!rst_n) begin
			wr_ptr <= 0;
			rd_ptr <= 0;
		end
		else begin
			if(rd_rewind)
				rd_ptr <= 0; 
			else if(!fifo_full && wr_en)
				wr_ptr <= wr_ptr + 1;
				
			if(!fifo_empty && rd_en)
				rd_ptr <= rd_ptr + 1;
		end
	end

endmodule 

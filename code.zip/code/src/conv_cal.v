`timescale      1ns/1ns

module  conv_cal #(
        parameter       W_WIDTH    =       16               ,//Ȩ��λ��
        parameter       B_WIDTH    =       16               ,//ƫ��λ��
		parameter       DATA_WIDTH =       16               ,//����λ�� 
		parameter       input_size =       66               ,//ͼƬ�ߴ�
	 	parameter       kernel_size=       3                 //�����˳ߴ�
)(
        // system signals
        input                   clk                     ,       
        input                   rst_n                   ,       
        // DATA RAM ����RAM���ӿ�
        output  reg     [ 6:0]  data_rd_addr            ,//���ݶ���ַ����66������RAM�ж�ȡ���ݡ���ȡ�����СΪ66��
        output  reg     [ 6:0]  row_cnt                 ,//�м�����������һ�еľ������֮�������������������ݶ���ַ������7λ������64��
        input           [ DATA_WIDTH*kernel_size-1:0]  col_data,//�����ݼĴ�����ͬʱ����һ�е����ݡ�ͨ��������Ĵ������ģ��ӳ�3�У���ò��������һ������Ұ��
        input                   cal_start               ,//����ʹ�ܣ����յ�����źź�conv��־�ź����ߣ���ʼ����
        // PARAM ROM Ȩ�ء�ƫ��ROM���ӿ�
        output  reg     [ 4:0]  param_rd_addr           ,//Ȩ��ROM����ַ��10*3*3��Ȩ�ط������д洢��ÿ��Rom�Ķ�ȡ���Ϊ30������5λ��
        output  reg     [ 3:0]  conv_cnt                ,//�����˼�������ͬʱ��Ϊƫ��ROM�Ķ���ַ������10�������ˡ�Ѱַ�������4λ��
        input    [W_WIDTH-1:0]  param_w_h0              ,//Ȩ�ػ���1
        input    [W_WIDTH-1:0]  param_w_h1              ,//Ȩ�ػ���2
        input    [W_WIDTH-1:0]  param_w_h2              ,//Ȩ�ػ���3������ƴ�ӳ�һ��������
        input    [B_WIDTH-1:0]  param_bias              ,//ƫ�û���
        
        output   [DATA_WIDTH-1:0]  conv_rslt_act ,//����relu���������ݣ�������������������������
        output   reg               conv_rslt_act_vld        //�����Ч�ź�
);

//========================================================================\
// =========== Define Parameter and Internal signals =========== 
//========================================================================/
//������־
reg                             conv_flag                       ;       
//�����˻���3*3
reg     [W_WIDTH*3-1:0]           param_w_h0_arr                  ;
reg     [W_WIDTH*3-1:0]           param_w_h1_arr                  ;
reg     [W_WIDTH*3-1:0]           param_w_h2_arr                  ;
//reg     [W_WIDTH*5-1]           param_w_h3_arr                  ;
//reg     [W_WIDTH*5-1]           param_w_h4_arr                  ;

//�����ݼĴ�������
reg     [ DATA_WIDTH*kernel_size-1:0]              col_data_r0  ;//��1�ģ���3��
reg     [ DATA_WIDTH*kernel_size-1:0]              col_data_r1  ;//��2�ģ���2��
reg     [ DATA_WIDTH*kernel_size-1:0]              col_data_r2  ;//��3�ģ���1��
//reg     [ 4:0]                  col_data_r3                     ;
//reg     [ 4:0]                  col_data_r4                     ;

wire    [15:0]                  mult00                          ;               
wire    [15:0]                  mult01                          ;               
wire    [15:0]                  mult02                          ;                             
        
wire    [15:0]                  mult10                          ;               
wire    [15:0]                  mult11                          ;               
wire    [15:0]                  mult12                          ;                            
         
wire    [15:0]                  mult20                          ;               
wire    [15:0]                  mult21                          ;               
wire    [15:0]                  mult22                          ;
wire    [15:0]                  sum                             ;

reg     [15:0]                  conv_rslt                       ;
wire                            valid_result                    ; 

wire                            mult_valid_00                    ;
wire                            mult_valid_01                   ;
wire                            mult_valid_02                    ;
wire                            mult_valid_10                    ;
wire                            mult_valid_11                    ;
wire                            mult_valid_12                    ;
wire                            mult_valid_20                    ;
wire                            mult_valid_21                    ;
wire                            mult_valid_22                    ;

reg                             cacl_valid                       ;
reg     [  3:0]                 conv_cnt_in                      ;
reg     [ 11:0]                 cnt                              ;
//=============================================================================
//**************    Main Code   **************
//=============================================================================

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_flag       <=      1'b0;                             
        else if(conv_cnt_in == 'd9 && row_cnt == 'd63 && data_rd_addr == 'd69)//���һ�������ˣ�9�������㵽���һ�У�63�������һ�У�69�����������
                conv_flag       <=      1'b0;
        else if(cal_start == 1'b1)
                conv_flag       <=      1'b1;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                param_rd_addr   <=      'd0; 
        else if(conv_flag == 1'b0)
                param_rd_addr   <=      'd0;
        else if(conv_flag == 1'b1 && row_cnt == 'd0 && data_rd_addr <= 'd2)//��ÿ�����ݶ���ַ��ǰ��λʱ����Ȩ��
                param_rd_addr   <=      param_rd_addr + 1'b1;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0) begin
                param_w_h0_arr  <=      'd0;
                param_w_h1_arr  <=      'd0;
                param_w_h2_arr  <=      'd0;
        end
        else if(data_rd_addr >= 'd1 && data_rd_addr <= 'd3 && row_cnt == 'd0) begin//����Ұ����
                param_w_h0_arr  <=      {param_w_h0, param_w_h0_arr[W_WIDTH*3-1:W_WIDTH]}; 
                param_w_h1_arr  <=      {param_w_h1, param_w_h1_arr[W_WIDTH*3-1:W_WIDTH]}; 
                param_w_h2_arr  <=      {param_w_h2, param_w_h2_arr[W_WIDTH*3-1:W_WIDTH]}; 
             //   param_w_h3_arr  <=      {param_w_h3, param_w_h3_arr[W_WIDTH*5-1:W_WIDTH]}; 
             //   param_w_h4_arr  <=      {param_w_h4, param_w_h4_arr[W_WIDTH*5-1:W_WIDTH]}; 
        end
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                row_cnt <=      'd0;
        else if(row_cnt == 'd63 && conv_flag == 1'b1 && data_rd_addr == 'd69)//һ�������˼�����ɺ���0
                row_cnt <=      'd0;
        else if(conv_flag == 1'b1 && data_rd_addr == 'd69)
                row_cnt <=      row_cnt + 1'b1;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                data_rd_addr    <=      'd0;
        else if(conv_flag == 1'b1 && data_rd_addr == 'd70)
                data_rd_addr    <=      'd0;
        else if(conv_flag == 1'b1)
                data_rd_addr    <=      data_rd_addr + 1'b1;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0) begin
                col_data_r0     <=      'd0;
                col_data_r1     <=      'd0;
                col_data_r2     <=      'd0;
              //col_data_r3     <=      'd0;
              //col_data_r4     <=      'd0;
        end
        else begin
              //col_data_r4     <=      col_data;
              //col_data_r3     <=      col_data_r4;
                col_data_r2     <=      col_data;
                col_data_r1     <=      col_data_r2;
                col_data_r0     <=      col_data_r1;
        end
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                cacl_valid       <=      1'b0;
        else if(data_rd_addr >= 'd4 && data_rd_addr <= 'd67)
                cacl_valid       <=      1'b1;
        else
                cacl_valid       <=      1'b0;
end
//////////////////////////////////////////////////////////////////////////////////
floating_mult_16 FM_00 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r0[DATA_WIDTH-1:0]  ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h0_arr[W_WIDTH-1:0] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_00),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult00)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_01 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r1[DATA_WIDTH-1:0] ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h0_arr[W_WIDTH*2-1:W_WIDTH] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_01),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult01)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_02 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r2[DATA_WIDTH-1:0]  ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h0_arr[W_WIDTH*3-1:W_WIDTH*2]),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_02),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult02)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_10 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r0[DATA_WIDTH*2-1:DATA_WIDTH]  ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h1_arr[W_WIDTH-1:0]  ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_10),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult10)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_11 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r1[DATA_WIDTH*2-1:DATA_WIDTH] ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h1_arr[W_WIDTH*2-1:W_WIDTH] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_11),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult11)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_12 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r2[DATA_WIDTH*2-1:DATA_WIDTH]    ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h1_arr[W_WIDTH*3-1:W_WIDTH*2] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_12),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult12)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_20 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r0[DATA_WIDTH*3-1:DATA_WIDTH*2]  ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h2_arr[W_WIDTH-1:0] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_20),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult20)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_21 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r1[DATA_WIDTH*3-1:DATA_WIDTH*2]   ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h2_arr[W_WIDTH*2-1:W_WIDTH] ),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_21),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult21)    // output wire [15 : 0] m_axis_result_tdata
);
floating_mult_16 FM_22 (
  .aclk(clk),                                  // input wire aclk
  .s_axis_a_tvalid(cacl_valid),            // input wire s_axis_a_tvalid
  .s_axis_a_tdata(col_data_r2[DATA_WIDTH*3-1:DATA_WIDTH*2]  ),              // input wire [15 : 0] s_axis_a_tdata
  .s_axis_b_tvalid(cacl_valid),            // input wire s_axis_b_tvalid
  .s_axis_b_tdata(param_w_h2_arr[W_WIDTH*3-1:W_WIDTH*2]),              // input wire [15 : 0] s_axis_b_tdata
  .m_axis_result_tvalid(mult_valid_22),  // output wire m_axis_result_tvalid
  .m_axis_result_tdata(mult22)    // output wire [15 : 0] m_axis_result_tdata
);
float16_10sum #(
    .DATA_WIDTH(DATA_WIDTH)
) u_float16_10sum (
    .aclk(clk),
    .aresetn(rst_n),
    .data_in_0(mult00),
    .valid_in_0(mult_valid_00),
    .data_in_1(mult01),
    .valid_in_1(mult_valid_01),
    .data_in_2(mult02),
    .valid_in_2(mult_valid_02),
    .data_in_3(mult10),
    .valid_in_3(mult_valid_10),
    .data_in_4(mult11),
    .valid_in_4(mult_valid_11),
    .data_in_5(mult12),
    .valid_in_5(mult_valid_12),
    .data_in_6(mult20),
    .valid_in_6(mult_valid_20),
    .data_in_7(mult21),
    .valid_in_7(mult_valid_21),
    .data_in_8(mult22),
    .valid_in_8(mult_valid_22),
    .data_in_9(param_bias),
    .valid_in_9(mult_valid_22),
    .sum_result(sum),
    .result_valid(valid_result)
);
//////////////////////////////////////////////////////////////////////////////////

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_cnt_in        <=      'd0;
        else if(conv_flag == 1'b0)
                conv_cnt_in        <=      'd0;
        else if(conv_flag == 1'b1 && row_cnt == 'd63 && data_rd_addr == 'd69)
                conv_cnt_in        <=      conv_cnt_in + 1'b1;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                cnt     <=      1'b0;                             
        else if(cnt == 12'd4095) //�������
                cnt     <=      'b0;
	    else if(mult_valid_00 == 1'd1)
		        cnt     <=   cnt + 1'd1;
end
//
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_cnt       <=      'b0;    
        else if(conv_cnt == 4'd9 && cnt == 12'd4095)
                conv_cnt       <=      'b0;		
        else if(cnt == 12'd4095)
                conv_cnt       <=      conv_cnt + 1;
end


always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_rslt       <=      'd0;
        else if(valid_result == 1)
                conv_rslt       <=      sum;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_rslt_act_vld       <=      1'b0;
        else if(valid_result == 1)
                conv_rslt_act_vld       <=      1'b1;
        else
                conv_rslt_act_vld       <=      1'b0;
end

assign  conv_rslt_act   = (conv_rslt[15] == 1'b0) ? conv_rslt : 'd0;


endmodule

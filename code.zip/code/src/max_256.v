module max_256_256#(
    parameter WINDOW_WIDTH = 256,
    parameter DATA_WIDTH = 16
)(  input clk,
    input rst_n,
    input [WINDOW_WIDTH*WINDOW_WIDTH*DATA_WIDTH-1:0]data_in,
    output reg[WINDOW_WIDTH*WINDOW_WIDTH*DATA_WIDTH/4-1:0]data_out
    );
localparam line_data = WINDOW_WIDTH*DATA_WIDTH;//����ǰ��һ�����ݳ��ȣ�ʾ��Ϊ256*16=4096
localparam progress_data = WINDOW_WIDTH/2*DATA_WIDTH;//�������һ�����ݳ��ȣ�ʾ��Ϊ128*16
localparam datawidth = DATA_WIDTH*2;
   genvar i,j;
    generate
        for(i=0;i<=WINDOW_WIDTH-1;i=i+2)begin
            for(j=datawidth-1; j<line_data; j=j+datawidth) begin: max_gen
                max_2_2  max_pool(
                    .clk(clk),
                    .rst_n(rst_n),
                    .data_in({data_in[i*line_data+j-:datawidth],data_in[j+(i+1)*line_data-:datawidth]}),
                    .data_out(data_out[j+i*progress_data-:DATA_WIDTH])
                );
            end
        end
    endgenerate
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)data_out<=0;
    else begin
    end                         
end
endmodule

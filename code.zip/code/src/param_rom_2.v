// *********************************************************************************
// Project Name : OSXXXX
// Author       : dengkanwen
// Email        : dengkanwen@163.com
// Website      : http://www.opensoc.cn/
// Create Time  : 2021-08-09 20:44:14
// File Name    : .v
// Module Name  : 
// Called By    :
// Abstract     :
//
// CopyRight(c) 2018, OpenSoc Studio.. 
// All Rights Reserved
//
// *********************************************************************************
// Modification History:
// Date         By              Version                 Change Description
// -----------------------------------------------------------------------
// 2021-08-09    Kevin           1.0                     Original
//  
// *********************************************************************************
`timescale      1ns/1ns

module  param_rom_2(
        // system signals
        input                   clk                     ,       
        input                   rst_n                   ,       
        // 
        input           [ 8:0]  param_rd_addr           ,//��������ַ
        input           [ 3:0]  feature_cnt             ,//����ͼ������������ƫ�ö�ȡ
        output  wire    [15:0]  param_w_h0              ,
        output  wire    [15:0]  param_w_h1              ,
        output  wire    [15:0]  param_w_h2              ,
        output  wire    [15:0]  param_bias              
);

//========================================================================\
// =========== Define Parameter and Internal signals =========== 
//========================================================================/



//=============================================================================
//**************    Main Code   **************
//=============================================================================
rom_2_b_ip        rom_2_b_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .ena                    (1'd1),
        .addra                  (feature_cnt           ),  // input wire [4 : 0] addra
        .douta                  (param_bias            )// output wire [15 : 0] douta
);

rom_2_w0_ip       rom_2_w0_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .ena                    (1'd1),
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h0             )// output wire [15 : 0] douta
);

rom_2_w1_ip       rom_2_w1_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .ena                    (1'd1),
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h1             )// output wire [15 : 0] douta
);

rom_2_w2_ip       rom_2_w2_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .ena                    (1'd1),
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h2             )// output wire [15 : 0] douta
);
endmodule

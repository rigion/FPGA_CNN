module softmax_top(//��С����ʽ��ʾ���ʣ�����0.987
    input[15:0]float1,
    input[15:0]float2,
    input[15:0]float3,
    input[15:0]float4,
    input start,
    input clk,
    input rst_n,
    output[3:0]tenth1,
    output[3:0]hundred1,
    output[3:0]thousand1,
    output[3:0]tenth2,
    output[3:0]hundred2,
    output[3:0]thousand2,
    output[3:0]tenth3,
    output[3:0]hundred3,
    output[3:0]thousand3,
    output[3:0]tenth4,
    output[3:0]hundred4,
    output[3:0]thousand4,
    output[3:0]sel
    );

wire[15:0]ans1,ans2,ans3,ans4,fixed_data;
wire done;
softmax exp(
    .float1(float1),
    .float2(float2),
    .float3(float3),
    .float4(float4),
    .start(start),
    .clk(clk),
    .rst_n(rst_n),
    .ans1(ans1),
    .ans2(ans2),
    .ans3(ans3),
    .ans4(ans4),
    .done(done)
    );
max_2_2 max(
    .a(ans1),
    .b(ans2),
    .c(ans3),
    .d(ans4),
    .valid_in(done),
    .clk(clk),
    .rst_n(rst_n),
    .led(sel)
);
wire[3:0]ten,thousand,hundred;
BCD bcd1(
    .clk(clk),
    .rst_n(rst_n),
    .float(ans1),
    .valid_in(done),
    .hundred_out(hundred1),
    .tenth_out(tenth1),
    .thousand_out(thousand1)
);
BCD bcd2(
    .clk(clk),
    .rst_n(rst_n),
    .float(ans2),
    .valid_in(done),
    .hundred_out(hundred2),
    .tenth_out(tenth2),
    .thousand_out(thousand2)
);
BCD bcd3(
    .clk(clk),
    .rst_n(rst_n),
    .float(ans3),
    .valid_in(done),
    .hundred_out(hundred3),
    .tenth_out(tenth3),
    .thousand_out(thousand3)
);
BCD bcd4(
    .clk(clk),
    .rst_n(rst_n),
    .float(ans4),
    .valid_in(done),
    .hundred_out(hundred4),
    .tenth_out(tenth4),
    .thousand_out(thousand4)
);

endmodule

`timescale 1ns / 1ps

module cacl_ctrl_4_param
#(
    parameter   FEATURE_NUM = 10,
	parameter   CONV_NUM    = 14,
	parameter   OUTPU_SIZE = 16,
	
	parameter   CONV_CNT_NUM   = 5,
	parameter   COL_CNT_NUM    = 5,
	parameter   ROW_CNT_NUM    = 5
)
(
    input      clk  ,
	input      rst_n,
	
	//fifo_ctrl���ݽӿ�
	input     wire   [15:0]  rd_data [FEATURE_NUM-1:0],//�������������
	input                    cal_start    ,//����ʹ��
	output                   rd_en        ,//��ʹ��
	//ƫ��rom�ӿ�
	input            [15:0]  param_data   ,//ƫ������
 	output    reg    [CONV_CNT_NUM-1:0]   conv_cnt     ,//ƫ�ö���ַ 
	//�������
	output          [15:0]   conv_act_rslt     ,//relu���
	output    reg            conv_act_vld  //���ʹ��
    );
//*******************��������****************************
reg               cacl_flag;
reg     [COL_CNT_NUM-1:0]     col_cnt;//�м�����
reg     [ROW_CNT_NUM-1:0]     row_cnt;//�м�����
reg     [15:0]    conv_rslt; 
wire    [15:0]    sum;
reg     [15:0]    conv_act;

wire              vaild;

//*******************Main code*****************************
//��ʹ��
assign  rd_en = cacl_flag;

//������־�źŶ���
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                cacl_flag       <=      1'b0;                             
        else if(conv_cnt == CONV_NUM&& row_cnt == OUTPU_SIZE-1 && col_cnt == OUTPU_SIZE-1)//�������
                cacl_flag       <=      1'b0;
        else if(cal_start == 1'b1)
                cacl_flag       <=      1'b1;
end
//�м�������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                row_cnt <=      'd0;
        else if(row_cnt == OUTPU_SIZE-1 && cacl_flag == 1'b1 && col_cnt == OUTPU_SIZE-1)//һ�������˼�����ɺ���0
                row_cnt <=      'd0;
        else if(cacl_flag == 1'b1 && col_cnt == OUTPU_SIZE-1)
                row_cnt <=      row_cnt + 1'b1;
end
//�м�������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                col_cnt    <=      'd0;
        else if(cacl_flag == 1'b1 && col_cnt == OUTPU_SIZE-1)
                col_cnt    <=      'd0;
        else if(cacl_flag == 1'b1)
                col_cnt    <=      col_cnt + 1'b1;
end
//�����˼���������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_cnt     <=      'd0;
		else if(cacl_flag == 1'b0)
                conv_cnt     <=      'd0;	
        else if(cacl_flag == 1'b1 && row_cnt == OUTPU_SIZE-1 && col_cnt == OUTPU_SIZE-2)
                conv_cnt        <=   conv_cnt + 1'b1;
end

float16_19sum #(
    .DATA_WIDTH(16)
) u_float16_19sum (
    .aclk(clk),
    .aresetn(rst_n),
    .data_in_0(rd_data[0]),
    .valid_in_0(cacl_flag),
    .data_in_1(rd_data[1]),
    .valid_in_1(cacl_flag),
    .data_in_2(rd_data[2]),
    .valid_in_2(cacl_flag),
    .data_in_3(rd_data[3]),
    .valid_in_3(cacl_flag),
    .data_in_4(rd_data[4]),
    .valid_in_4(cacl_flag),
    .data_in_5(rd_data[5]),
    .valid_in_5(cacl_flag),
    .data_in_6(rd_data[6]),
    .valid_in_6(cacl_flag),
    .data_in_7(rd_data[7]),
    .valid_in_7(cacl_flag),
    .data_in_8(rd_data[8]),
    .valid_in_8(cacl_flag),
    .data_in_9(rd_data[9]),
    .valid_in_9(cacl_flag),
	.data_in_10(rd_data[10]),
    .valid_in_10(cacl_flag),
    .data_in_11(rd_data[11]),
    .valid_in_11(cacl_flag),
    .data_in_12(rd_data[12]),
    .valid_in_12(cacl_flag),
    .data_in_13(rd_data[13]),
    .valid_in_13(cacl_flag),
    .data_in_14(rd_data[14]),
    .valid_in_14(cacl_flag),
	.data_in_15(rd_data[15]),
    .valid_in_15(cacl_flag),
	.data_in_16(rd_data[16]),
    .valid_in_16(cacl_flag),
	.data_in_17(rd_data[17]),
    .valid_in_17(cacl_flag),
	.data_in_18(param_data),
    .valid_in_18(cacl_flag),
    .sum_result(sum),
    .result_valid(vaild)
);

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_act       <=      'd0;
        else if(vaild == 1)
                conv_act       <=      sum;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_act_vld       <=      1'b0;
        else 
		        conv_act_vld       <=      vaild;
end

assign  conv_act_rslt = (conv_act[15] == 1'b0) ? conv_act : 'd0;

endmodule

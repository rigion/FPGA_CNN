module image_rx_ctrl (
  input             clk                ,
  input             rst_n              ,
  input             image_data_valid   ,
  output reg [15:0] image_data_hcnt    ,
  output reg [15:0] image_data_vcnt    ,
  output reg        image_data_hs      ,
  output reg        image_data_vs      
);
localparam DISP_WIDTH  = 256;
localparam DISP_HEIGHT = 256;
  //generate image data hs or vs
  always@(posedge clk or negedge rst_n)
    if(!rst_n)
      image_data_hcnt <= 'd0;
    else if(image_data_valid) begin
      if(image_data_hcnt == (DISP_WIDTH - 1'b1))
        image_data_hcnt <= 'd0;
      else
        image_data_hcnt <= image_data_hcnt + 1'b1;
    end

  always@(posedge clk or negedge rst_n)
    if(!rst_n)
      image_data_vcnt <= 'd0;
    else if(image_data_valid) begin
      if(image_data_hcnt == (DISP_WIDTH - 1'b1)) begin
        if(image_data_vcnt == (DISP_HEIGHT - 1'b1))
          image_data_vcnt <= 'd0;
        else
          image_data_vcnt <= image_data_vcnt + 1'b1;
      end
    end
  //hs
  always@(posedge clk or negedge rst_n)
    if(!rst_n)
      image_data_hs <= 1'b0;
    else if(image_data_valid && image_data_hcnt == (DISP_WIDTH - 1'b1))
      image_data_hs <= 1'b0;
    else
      image_data_hs <= 1'b1;
  //vs
  always@(posedge clk or negedge rst_n)
    if(!rst_n)
      image_data_vs <= 1'b0;
    else if(image_data_valid && image_data_hcnt == (DISP_WIDTH - 1'b1) &&
            image_data_vcnt == (DISP_HEIGHT - 1'b1))
      image_data_vs <= 1'b0;
    else
      image_data_vs <= 1'b1;

endmodule

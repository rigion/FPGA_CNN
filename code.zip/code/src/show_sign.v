module show_sign(
    input clk,
    input[9:0]addr,     
    output sign_data
    );
wire[31:0]rom_data;
reg[4:0]col_reg;        
reg[4:0]row_index;  
reg[4:0]col_index;
sign rom(
  .clka(clk),    
  .addra(row_index),  
  .douta(rom_data) 
);
always @(posedge clk) begin
    row_index<=addr[9:5];
    col_index<=31-addr[4:0];
    // Stage 2: ������������ROM����
    col_reg  <= col_index;
end
assign sign_data=rom_data[col_reg];
endmodule

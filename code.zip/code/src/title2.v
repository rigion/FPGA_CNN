module title2(
    input clk,
    input[11:0]addr,
    output title_data
    );
wire[127:0]rom_data;
reg[6:0]col_reg;        
reg[4:0]row_index;  
reg[6:0]col_index;
zdjg rom(
  .clka(clk),    // input wire clka
  .addra(row_index),  
  .douta(rom_data)  
);
always @(posedge clk) begin
    row_index<=addr[11:7];
    col_index<=127-addr[6:0];
    // Stage 2: ������������ROM����
    col_reg  <= col_index;
end
assign title_data=rom_data[col_reg];
endmodule

/* PADDING.v */
module PADDING
#(
	parameter DATA_WIDTH = 16,
	parameter FMAP_SIZE = 64,
	parameter N = 1,
	parameter CNT_BIT_NUM = 7,
	parameter LINE_CNT_BIT_NUM = 7
)
(
	input clk,
	input rst_n,
	input ena,
	input clear,
	input [DATA_WIDTH-1:0]fmap_raw,
	output [DATA_WIDTH-1:0]fmap_pad,
	output rd_en,
	output valid,
	output done,
	output reg [LINE_CNT_BIT_NUM-1:0] cnt_col_1,
	output reg [LINE_CNT_BIT_NUM-1:0] cnt_row_1
);
    reg [12:0]cnt;
    reg [LINE_CNT_BIT_NUM-1:0] cnt_col;
	reg [LINE_CNT_BIT_NUM-1:0] cnt_row;
	
    always @(posedge clk or negedge rst_n)begin
		if(!rst_n)begin
			cnt_col <= 0;
			cnt_row <= 0;
		end
		else if(clear)begin
			cnt_col <= 0;
			cnt_row <= 0;
		end
		else if(flag) begin
			cnt_col<=cnt_col_1;
			cnt_row<=cnt_row_1;
		end
	end
    
    assign flag = ena||
    (cnt>0 && cnt <= (FMAP_SIZE + N * 2) * (FMAP_SIZE + N * 2) - 1);

	function integer clogb2 (input integer bit_depth);
	begin
		for(clogb2=0; bit_depth>0; clogb2=clogb2+1)
		bit_depth = bit_depth >> 1;
	end
	endfunction
	
	
	assign valid = (flag) ? ((cnt <= (FMAP_SIZE + N * 2) * (FMAP_SIZE + N * 2) - 1) ? 1 : 0) : 0;
	assign done = (flag) ? ((cnt == (FMAP_SIZE + N * 2) * (FMAP_SIZE + N * 2) - 1) ? 1 : 0) : 0;
	assign fmap_pad = (!flag || cnt_row_1 < N  || cnt_row_1 > FMAP_SIZE + N - 1) ? 0 : ((cnt_col_1 < N || cnt_col_1 > FMAP_SIZE + N - 1) ? 0 : fmap_raw);
	
	//conditional generate
	generate 
		if(N != 0) begin: no_padding
			assign rd_en = (!flag || cnt_row_1 < N|| cnt_row_1 > FMAP_SIZE + N - 1) ? 0 : ((cnt_col < FMAP_SIZE + N  && cnt_col > FMAP_SIZE + N-3) ? 0 : 1);
		end
		else begin: padding
			assign rd_en = (flag) ? 1 : 0;
		end
	endgenerate
	
	always @(posedge clk or negedge rst_n)
		if(!rst_n)
			cnt <= 0;
		else if(clear)
			cnt <= 0;
		else if(flag) begin
			if(cnt == (FMAP_SIZE + N * 2) * (FMAP_SIZE + N * 2) - 1) 
				cnt <= 0;
			else
				cnt <= cnt + 1;
		end
		
	always @(posedge clk or negedge rst_n)
		if(!rst_n) begin
			cnt_col_1 <= 0;
			cnt_row_1 <= 0;
		end
		else if(clear) begin
			cnt_col_1 <= 0;
			cnt_row_1 <= 0;	
		end
		else if(flag) begin
			if (cnt_col_1 >= FMAP_SIZE + N * 2 - 1) begin
				cnt_col_1 <= 0;
				cnt_row_1 <= cnt_row_1 + 1;
			end
			else 
				cnt_col_1 <= cnt_col_1 + 1;
		end
				
endmodule

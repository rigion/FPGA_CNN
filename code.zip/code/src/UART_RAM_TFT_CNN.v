module UART_RAM_TFT_CNN (
    input               Clk,
    input               Reset_n,
    input               uart_rx,
    input               sobel_enable,
    // TFT ��ʾ�˿ڣ�����ԭ���룩
    output      [15:0]  VGA_RGB,
    output              VGA_HS,
    output              VGA_VS,
    output              VGA_BLK,
    output              VGA_CLK,
    output              TFT_BL
);
    //========================
    // ʱ�� / ����
    //========================
    wire Clk_TFT;    wire Clk_100;
    assign VGA_CLK = Clk_TFT;
    assign TFT_BL  = 1'b1;

    MMCM u_mmcm (
        .clk_out1 (Clk_TFT),
        .clk_out2(Clk_100),
        .clk_in1  (Clk)
    );
    //========================
    // ���ڽ����ֽ�
    //========================
    wire [7:0] rx_data;
    wire       rx_done;

    uart_byte_rx u_uart_byte_rx(
        .clk      (Clk_100),
        .reset_n  (Reset_n),
        .baud_set (5),
        .uart_rx  (uart_rx),
        .data_byte(rx_data),
        .rx_done  (rx_done)
    );

    //========================
    // ���� �� RGB565 ����д��
    //========================
    wire        ram_wren1;
    wire [15:0] ram_wraddr1;   // 0..65535������ֻ�� 256x256 �õ���
    wire [15:0] ram_wrdata1;   // RGB565
    wire        refresh;
    img_rx_wr u_img_rx_wr(
        .Clk        (Clk_100),
        .Reset_n    (Reset_n),
        .rx_data    (rx_data),
        .rx_done    (rx_done),
        .ram_wren   (ram_wren1),
        .ram_wraddr (ram_wraddr1),
        .ram_wrdata (ram_wrdata1),
        .refresh    (refresh)
    );
    wire hs_in,vs_in;
    wire hs_out,vs_out;
    image_rx_ctrl image_ctrl(
        .clk(Clk_100)               ,
        .rst_n(Reset_n)           ,
        .image_data_valid(ram_wren1)  ,
        .image_data_hcnt()   ,
        .image_data_vcnt()   ,
        .image_data_hs(hs_in)   ,
        .image_data_vs(vs_in)  
    );
    // д��ַ 3 �����루������ԭ����һ�£�
    reg [15:0] ram_wraddr, ram_wraddr2, ram_wraddr3;
    wire[15:0]ram_addr;
    always @(posedge Clk_100 or negedge Reset_n) begin
        if(!Reset_n) begin
            ram_wraddr  <= 16'd0;
            ram_wraddr2 <= 16'd0;
            ram_wraddr3 <= 16'd0;
        end else begin
            ram_wraddr2 <= ram_wraddr1;
            ram_wraddr3 <= ram_wraddr2;
            ram_wraddr  <= ram_wraddr3;
        end
    end

    wire sobel_v;wire[6:0]sobel_out;
    sobel s(
        .clk(Clk_100),    //pixel clk
        .rst_n(Reset_n),
        .data_in(g8_0),
        .addr_in(ram_wraddr),
        .data_in_valid(g_vld0),
        .data_in_hs(hs_out),
        .data_in_vs(vs_out),
        .data_out(sobel_out),
        .addr_out(ram_addr),
        .data_out_valid(sobel_v)
    );
    

    // ��ʾ RAM��˫�ڣ�
    reg  [15:0] ram_rdaddr;       // ����ַ������ʱ����+������
    wire [6:0] ram_rddata;

    RAM u_ram (
        .clka   (Clk_100),
        .wea    (sobel_v),
        .addra  (ram_addr),
        .dina   (sobel_out),

        .clkb   (Clk_TFT),
        .addrb  (ram_rdaddr),
        .doutb  (ram_rddata)
    );

    // VGA ���ƣ�����ԭ���룩
    wire        Data_Req;
    wire [11:0] hcount, vcount;
    reg [15:0] disp_data;

    VGA_CTRL u_vga_ctrl(
        .Clk      (Clk_TFT),
        .Reset_n  (Reset_n),
        .Data     (disp_data),
        .Data_Req (Data_Req),
        .hcount   (hcount),
        .vcount   (vcount),
        .VGA_RGB  (VGA_RGB),
        .VGA_HS   (VGA_HS),
        .VGA_VS   (VGA_VS),
        .VGA_BLK  (VGA_BLK)
    );

     wire ram_data_en,font_data_en,font_data,sign_en,result_en;
    reg[14:0]addr_font;
    reg[9:0]addr_sign;
    reg[12:0]addr_result;
    wire sign_data,result_data;

    reg[8:0]num_addr1,num_addr2,num_addr3;
    wire num_data1,num_en1,num_data2,num_data3,num_en2,num_en3;
    reg[1:0]num_cnt;

    wire[3:0]tenth1,hundred1,thousand1;
    wire[3:0]tenth2,hundred2,thousand2;
    wire[3:0]tenth3,hundred3,thousand3;
    wire[3:0]tenth4,hundred4,thousand4;
    wire[3:0]sel;
    show_num num1(//ÿһ��shownumģ����ʾһ���ĸ���
        .clk(Clk_TFT),
        .num0(tenth1),
        .num1(tenth2),
        .num2(tenth3),
        .num3(tenth4),
        .cnt(num_cnt),
        .addr(num_addr1),     
        .num_data(num_data1)
    );
    show_num num2(
        .clk(Clk_TFT),
        .num0(hundred1),
        .num1(hundred2),
        .num2(hundred3),
        .num3(hundred4),
        .cnt(num_cnt),
        .addr(num_addr2),     
        .num_data(num_data2)
    );
    show_num num3(
        .clk(Clk_TFT),
        .num0(thousand1),
        .num1(thousand2),
        .num2(thousand3),
        .num3(thousand4),
        .cnt(num_cnt),
        .addr(num_addr3),     
        .num_data(num_data3)
    );
    read_ROM font(
        .clk(Clk_TFT),
        .addr1(addr_font),    
        .font_data(font_data),
        .sel(sel),
        .addr2(addr_result),
        .result(result_data)
    );
    show_sign sign(
        .clk(Clk_TFT),
        .addr(addr_sign),     
        .sign_data(sign_data)
    );
    reg[12:0]t1_addr;
    wire t1_data,t1_en;
    title1 t1(
        .clk(Clk_TFT),
        .addr(t1_addr),
        .title_data(t1_data)
    );
    reg[11:0]t2_addr;
    wire t2_data,t2_en;
    title2 t2(
        .clk(Clk_TFT),
        .addr(t2_addr),
        .title_data(t2_data)
    );
    wire pic_en;
    pic_ctrl show_pic_en(
        .rst_n(Reset_n),
        .valid(sobel_v),
        .addr(ram_addr),
        .clk(Clk_100),
        .pic_en(pic_en)
    );
    //RAM�д洢��ͼ����256*256�����ؾ���
    reg result_en_reg;
    always@(posedge Clk_TFT or negedge Reset_n)begin
        if(!Reset_n)begin
            ram_rdaddr <= 0; 
            addr_font<=0;
            addr_sign<=0;
            addr_result<=0;
            num_addr1<=0;
            num_addr2<=0;
            num_addr3<=0;
            num_cnt<=0;
            t1_addr<=0;
            t2_addr<=0;
        end  
        else begin
            result_en_reg<=result_en;
            case({ram_data_en,font_data_en,sign_en,result_en,num_en1,num_en2,num_en3,t1_en,t2_en})
                9'b100000000:ram_rdaddr <= ram_rdaddr + 1'd1;
                9'b010000000:addr_font <= (addr_font==15'd20479)?0:addr_font+1;
                9'b001000000:addr_sign<=addr_sign+1;
                9'b000100000:addr_result<=(addr_result==13'd5119)?0:addr_result+1;
                9'b000010000:num_addr1<=num_addr1+1;
                9'b000001000:num_addr2<=num_addr2+1;
                9'b000000100:begin
                    num_addr3<=num_addr3+1;
                    num_cnt<=(num_addr3==9'd511)?(num_cnt+1):num_cnt;
                end
                9'b000000010:t1_addr<=t1_addr+1;
                9'b000000001:t2_addr<=t2_addr+1;
                default:begin
                    ram_rdaddr<=ram_rdaddr;
                    addr_font<=addr_font;
                    addr_sign<=addr_sign;
                    addr_result<=addr_result;
                    num_addr1<=num_addr1;
                    num_addr2<=num_addr2;
                    num_addr3<=num_addr3;
                    t1_addr<=t1_addr;
                    t2_addr<=t2_addr;
                end
            endcase
        end
    end
wire line_en;
assign t1_en=Data_Req&&((hcount >= 80 && hcount < 176)||(hcount >= 580 && hcount < 740)) && ( vcount >= 50 && vcount < 82);
assign t2_en=Data_Req&&(hcount >= 30 && hcount < 158) && ( vcount >= 400 && vcount <432);
assign font_data_en=Data_Req&&(hcount >= 5 && hcount < 165) && ( vcount >= 90 && vcount < 218);//���������Ч
assign ram_data_en =Data_Req&&(hcount >= 524 && hcount < 780) && ( vcount >= 90 && vcount < 346);//ͼ�������Ч
assign sign_en=Data_Req&&((hcount>=202&&hcount<218)||(hcount>=234&&hcount<250))&&(vcount>=90&&vcount<218);//���������Ч
assign result_en=Data_Req&&(hcount >=180 && hcount < 340) && ( vcount >=400 && vcount <432);//��������Ч
assign num_en1=Data_Req&&(hcount>=170&&hcount<186)&&(vcount>=90&&vcount<218);
assign num_en2=Data_Req&&(hcount>=186&&hcount<202)&&(vcount>=90&&vcount<218);
assign num_en3=Data_Req&&(hcount>=218&&hcount<234)&&(vcount>=90&&vcount<218);
assign line_en=Data_Req&&((vcount==45)||(vcount==85)||(vcount==390&&hcount<=350)||(vcount==440)||(vcount>45&&vcount<440&&hcount==350));
always @(*) begin
    case({ram_data_en,font_data_en,sign_en,result_en_reg,num_en1,num_en2,num_en3,t1_en,t2_en,line_en})
        10'b1000000000:begin
                // if(sobel_enable) disp_data={ram_rddata[6:2],ram_rddata[6:1],ram_rddata[6:2]};
                // else disp_data={16{ram_rddata[0]}};
                case({sobel_enable,pic_en})
                    2'b11:disp_data={ram_rddata[6:2],ram_rddata[6:1],ram_rddata[6:2]};
                    2'b01:disp_data={16{ram_rddata[0]}};
                    default:disp_data=16'b0;
                endcase
            end
        10'b0100000000:disp_data={16{font_data}};
        10'b0010000000:disp_data={16{sign_data}};
        10'b0001000000:disp_data={16{result_data}};
        10'b0000100000:disp_data={16{num_data1}};
        10'b0000010000:disp_data={16{num_data2}};
        10'b0000001000:disp_data={16{num_data3}};
        10'b0000000100:disp_data={16{t1_data}};
        10'b0000000010:disp_data={16{t2_data}};
        10'b0000000001:disp_data={16'b1111111111111111};
        default:disp_data=16'b0;
    endcase
end

        //========================================================
    // ��CNN ֧·��RGB565 �� �Ҷ�8 �� FP16 ��һ�� �� �ػ���2 �� 64x64
// CNN֧·��ת��ʹ�øĽ��ĳػ�ģ��
wire        g_vld0;
wire [7:0]  g8_0;
rgb565_to_gray8 u_cnn_gray (
    .clk      (Clk_100),
    .rst_n    (Reset_n),
    .hs_in(hs_in),
    .vs_in(vs_in),
    .vs_out(vs_out),
    .hs_out(hs_out),
    .valid_i  (ram_wren1),
    .rgb565_i (ram_wrdata1),
    .valid_o  (g_vld0),
    .gray8_o  (g8_0)
);

// 2) �Ҷ�8 -> FP16 ��һ����2�ģ����� Python һ�£�RNE��
wire        v_fp16;
wire [15:0] fp16_0;
gray8_to_FP16_norm_257 u_norm_fp16 (
    .clk     (Clk_100),
    .rst_n   (Reset_n),
    .valid_i (g_vld0),
    .gray8_i (g8_0),
    .valid_o (v_fp16),
    .fp16_o  (fp16_0)
);

wire[15:0]data_out_0,data_out_1,data_out_2,data_out_3;
wire en_out;
cnn_top u_cnn_top
(
     .clk            (Clk_100)  ,
	 .rst_n          (Reset_n&&refresh)  ,
	                            
	 //��һ���ػ�������            
	 .valid_in        (v_fp16)  ,
	 .data_in         (fp16_0)  ,
	                            
	 //ȫ���Ӳ����          
	 .en_out          (en_out)  ,
	 .data_out_0      (data_out_0),
	 .data_out_1      (data_out_1),
	 .data_out_2      (data_out_2),
	 .data_out_3      (data_out_3)
    );
softmax_top soft(
    .float1(data_out_0),
    .float2(data_out_1),
    .float3(data_out_2),
    .float4(data_out_3),
    .start(en_out),
    .clk(Clk_100),
    .rst_n(Reset_n),
    .tenth1(tenth1),
    .hundred1(hundred1),
    .thousand1(thousand1),
    .tenth2(tenth2),
    .hundred2(hundred2),
    .thousand2(thousand2),
    .tenth3(tenth3),
    .hundred3(hundred3),
    .thousand3(thousand3),
    .tenth4(tenth4),
    .hundred4(hundred4),
    .thousand4(thousand4),
    .sel(sel)
    );
endmodule
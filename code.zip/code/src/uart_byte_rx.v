module uart_byte_rx(
  input           clk,       //ʱ������
  input           reset_n,     //��λ�ź�����

  input      [2:0]baud_set,  //����������
  input           uart_rx,   //���������ź�

  output reg [7:0]data_byte, //���ڽ��յ�1byte����
  output reg      rx_done   //1byte���ݽ�����ɱ�־

);
  
  parameter  CLK_FRQ          = 100000000;
  localparam BAUD_9600_CNT    = CLK_FRQ/9600/16 - 1;
  localparam BAUD_19200_CNT   = CLK_FRQ/19200/16 - 1;
  localparam BAUD_38400_CNT   = CLK_FRQ/38400/16 - 1;
  localparam BAUD_57600_CNT   = CLK_FRQ/57600/16 - 1;
  localparam BAUD_115200_CNT  = CLK_FRQ/115200/16 - 1;
  localparam BAUD_1562500_CNT = CLK_FRQ/1562500/16 - 1;

  reg uart_rx_sync1;   //ͬ���Ĵ���
  reg uart_rx_sync2;   //ͬ���Ĵ���

  reg uart_rx_reg1;    //���ݼĴ���
  reg uart_rx_reg2;    //���ݼĴ���

  reg [15:0]bps_DR;    //��Ƶ�������ֵ
  reg [15:0]div_cnt;   //��Ƶ������
  reg       bps_clk;   //������ʱ��
  reg [7:0] bps_cnt;   //������ʱ�Ӽ�����
  reg       uart_state;//��������״̬

  wire      uart_rx_nedge;

  reg [2:0] START_BIT;
  reg [2:0] STOP_BIT;
  reg [2:0] data_byte_pre [7:0];

  //ͬ�����������źţ���������̬
  always@(posedge clk)
  begin
    uart_rx_sync1 <= uart_rx;
    uart_rx_sync2 <= uart_rx_sync1;
  end

  //���ݼĴ���
  always@(posedge clk)
  begin
    uart_rx_reg1 <= uart_rx_sync2;
    uart_rx_reg2 <= uart_rx_reg1;
  end

  //�½��ؼ��
  assign uart_rx_nedge = !uart_rx_reg1 & uart_rx_reg2;

  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    bps_DR <= BAUD_9600_CNT;
  else begin
    case(baud_set)
      0:bps_DR <= BAUD_9600_CNT;
      1:bps_DR <= BAUD_19200_CNT;
      2:bps_DR <= BAUD_38400_CNT;
      3:bps_DR <= BAUD_57600_CNT;
      4:bps_DR <= BAUD_115200_CNT;
      5:bps_DR <= BAUD_1562500_CNT;
      default:bps_DR <= BAUD_9600_CNT;
    endcase
  end

  //counter
  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    div_cnt <= 16'd0;
  else if(uart_state)begin
    if(div_cnt == bps_DR)
      div_cnt <= 16'd0;
    else
      div_cnt <= div_cnt + 1'b1;
  end
  else
    div_cnt <= 16'd0;

  // bps_clk gen
  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    bps_clk <= 1'b0;
  else if(div_cnt == 16'd1)
    bps_clk <= 1'b1;
  else
    bps_clk <= 1'b0;

  //bps counter
  always@(posedge clk or negedge reset_n)
  if(!reset_n)  
    bps_cnt <= 8'd0;
  else if(rx_done || (bps_cnt == 8'd12 && (START_BIT > 2)))
    bps_cnt <= 8'd0;
  else if(bps_clk)
    bps_cnt <= bps_cnt + 1'b1;
  else
    bps_cnt <= bps_cnt;

  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    rx_done <= 1'b0;
  else if(bps_clk && (bps_cnt == 8'd155)) //��ǰ��������źţ��������ݾ����պ�Ϳ�����Ϊ���ν������
    rx_done <= 1'b1;
  else
    rx_done <= 1'b0;

  always@(posedge clk or negedge reset_n)
  if(!reset_n)begin
    START_BIT        <= 3'd0;
    data_byte_pre[0] <= 3'd0;
    data_byte_pre[1] <= 3'd0;
    data_byte_pre[2] <= 3'd0;
    data_byte_pre[3] <= 3'd0;
    data_byte_pre[4] <= 3'd0;
    data_byte_pre[5] <= 3'd0;
    data_byte_pre[6] <= 3'd0;
    data_byte_pre[7] <= 3'd0;
    STOP_BIT         <= 3'd0;
  end
  else if(bps_clk)begin
    case(bps_cnt)
      0:begin
        START_BIT        <= 3'd0;
        data_byte_pre[0] <= 3'd0;
        data_byte_pre[1] <= 3'd0;
        data_byte_pre[2] <= 3'd0;
        data_byte_pre[3] <= 3'd0;
        data_byte_pre[4] <= 3'd0;
        data_byte_pre[5] <= 3'd0;
        data_byte_pre[6] <= 3'd0;
        data_byte_pre[7] <= 3'd0;
        STOP_BIT         <= 3'd0;
      end
      6  ,7  ,8  ,9  ,10 ,11 :START_BIT        <= START_BIT        + uart_rx_sync2;
      22 ,23 ,24 ,25 ,26 ,27 :data_byte_pre[0] <= data_byte_pre[0] + uart_rx_sync2;
      38 ,39 ,40 ,41 ,42 ,43 :data_byte_pre[1] <= data_byte_pre[1] + uart_rx_sync2;
      54 ,55 ,56 ,57 ,58 ,59 :data_byte_pre[2] <= data_byte_pre[2] + uart_rx_sync2;
      70 ,71 ,72 ,73 ,74 ,75 :data_byte_pre[3] <= data_byte_pre[3] + uart_rx_sync2;
      86 ,87 ,88 ,89 ,90 ,91 :data_byte_pre[4] <= data_byte_pre[4] + uart_rx_sync2;
      102,103,104,105,106,107:data_byte_pre[5] <= data_byte_pre[5] + uart_rx_sync2;
      118,119,120,121,122,123:data_byte_pre[6] <= data_byte_pre[6] + uart_rx_sync2;
      134,135,136,137,138,139:data_byte_pre[7] <= data_byte_pre[7] + uart_rx_sync2;
      150,151,152,153,154,155:STOP_BIT         <= STOP_BIT         + uart_rx_sync2;
      default:
      begin
        START_BIT        <= START_BIT;
        data_byte_pre[0] <= data_byte_pre[0];
        data_byte_pre[1] <= data_byte_pre[1];
        data_byte_pre[2] <= data_byte_pre[2];
        data_byte_pre[3] <= data_byte_pre[3];
        data_byte_pre[4] <= data_byte_pre[4];
        data_byte_pre[5] <= data_byte_pre[5];
        data_byte_pre[6] <= data_byte_pre[6];
        data_byte_pre[7] <= data_byte_pre[7];
        STOP_BIT         <= STOP_BIT;
      end
    endcase
  end

  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    data_byte <= 8'd0;
  else if(bps_clk && (bps_cnt == 8'd155))begin //�������ݾ����պ�Ϳ�����������
    data_byte[0] <= data_byte_pre[0][2];
    data_byte[1] <= data_byte_pre[1][2];
    data_byte[2] <= data_byte_pre[2][2];
    data_byte[3] <= data_byte_pre[3][2];
    data_byte[4] <= data_byte_pre[4][2];
    data_byte[5] <= data_byte_pre[5][2];
    data_byte[6] <= data_byte_pre[6][2];
    data_byte[7] <= data_byte_pre[7][2];
  end

  always@(posedge clk or negedge reset_n)
  if(!reset_n)
    uart_state <= 1'b0;
  else if(uart_rx_nedge)
    uart_state <= 1'b1;
  else if(rx_done || (bps_cnt == 8'd12 && (START_BIT > 2)) || (bps_cnt == 8'd155 && (STOP_BIT < 3)))
    uart_state <= 1'b0;
  else
    uart_state <= uart_state;

endmodule
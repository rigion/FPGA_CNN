//��������������2*2����
module window
#(parameter picture_width = 256)(
    input valid_in,
    input [15:0]data_in,
    input clk,
    input rst_n,
    output reg valid_out,
    output reg[15:0]data_out1,
    output reg[15:0]data_out2,
    output reg[15:0]data_out3,
    output reg[15:0]data_out4
    );
reg[7:0]cnt_row,cnt_col;
reg[8:0]i;
reg[15:0]row_data[0:picture_width-1];
always@(posedge clk or negedge rst_n)begin
    if(!rst_n)begin
        cnt_row<=0;
        cnt_col<=0;
    end
    else begin
        if(valid_in)begin
            if(cnt_col==picture_width-1)begin
                if(cnt_row==picture_width-1)begin
                    cnt_col<=0;
                    cnt_row<=0;
                end
                else begin
                    cnt_col<=0;
                    cnt_row<=cnt_row+1;
                end
            end
            else cnt_col<=cnt_col+1;
        end
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        for(i=0;i<picture_width;i=i+1)row_data[i]<=0;
    else begin//ż���д�������
        if(valid_in&&(!cnt_row[0]))row_data[cnt_col]<=data_in;
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        data_out1<=0;
        data_out2<=0;
        data_out3<=0;
        data_out4<=0;
        valid_out<=0;
    end
    else begin//���������
        if(valid_in&&cnt_row[0])begin
            if(cnt_col[0])begin
                valid_out<=1;
                data_out1<=data_in;
                data_out3<=row_data[cnt_col];
            end 
            else begin
                valid_out<=0;
                data_out2<=data_in;
                data_out4<=row_data[cnt_col];
            end
        end
        else valid_out<=0;
    end
end
endmodule

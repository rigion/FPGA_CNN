module pic_ctrl(
    input rst_n,
    input valid,
    input[15:0]addr,
    input clk,
    output reg pic_en
    );
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)pic_en<=1'b0;
    else if(valid&&addr==16'd65535)pic_en<=1'b1;
end
endmodule
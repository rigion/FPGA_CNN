module compare_2(
    input [15:0] A,
    input [15:0] B,
    input valid_in,
    input        clk,
    input        rst_n,
    output reg   check,
    output reg valid_out
);
    // ��ȡ�ֶ�
    wire A_sign = A[15];
    wire B_sign = B[15];

    // ƴ��ָ����β�����ڱȽϣ��޷��ţ�
    wire [14:0] A_mag = A[14:0];
    wire [14:0] B_mag = B[14:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n||!valid_in) begin
            check <= 1'b0;
            valid_out<=0;
        end else begin
            valid_out<=1;
            case ({A_sign,B_sign})
                2'b01: check<=1;
                2'b10: check<=0;
                2'b00: check<=(A_mag >= B_mag);
                2'b11: check<=(A_mag <= B_mag);
                default:check<=0;
            endcase
        end
    end
endmodule
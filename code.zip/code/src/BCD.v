//ģ�鹦�ܣ�FP16תʮ����
module BCD(
    input clk,
    input rst_n,
    input[15:0]float,
    input valid_in,
    output reg[3:0]hundred_out,
    output reg[3:0]tenth_out,
    output reg[3:0]thousand_out
    );
reg[12:0]num;
reg done1;
reg[3:0]shift;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n||!valid_in)begin
        num<=0;
        done1<=0;
        shift<=0;
    end
    else begin
        done1<=valid_in;
        shift<=(15-float[14:10]);//Ĭ������<=1
        num<={1'b1,float[9:0],2'b0};//����Ĳ��㲻Ҫȥ��
    end
end
wire uints;//��������
wire[11:0]frac;//С������
wire[12:0]num2;
assign num2=num>>shift;
assign uints=num2[12];
assign frac=num2[11:0];
reg[15:0]multi1;
reg uints1,done2;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        multi1<=0;
        uints1<=0;
        done2<=0;
    end
    else begin
        done2<=done1;
        multi1<=(frac<<3)+(frac<<1);
        uints1<=uints;
    end
end
wire[3:0]tenth;
wire[11:0]frac2;
assign tenth=multi1[15:12];
assign frac2=multi1[11:0];

reg[15:0]multi2;
reg uints2,done3;
reg[3:0]tenth2;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        multi2<=0;
        uints2<=0;
        tenth2<=0;
        done3<=0;
    end
    else begin
        done3<=done2;
        multi2<=(frac2<<3)+(frac2<<1);
        uints2<=uints1;
        tenth2<=tenth;
    end
end
wire[3:0]hundred;
wire[11:0]frac3;
assign hundred=multi2[15:12];
assign frac3=multi2[11:0];

reg[15:0]multi3;
reg uints3,done4;
reg[3:0]tenth3,hundred3;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        multi3<=0;
        uints3<=0;
        tenth3<=0;
        hundred3<=0;
        done4<=0;
    end
    else begin
        done4<=done3;
        multi3<=(frac3<<3)+(frac3<<1);
        uints3<=uints2;
        tenth3<=tenth2;
        hundred3<=hundred;
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        thousand_out<=0;
        tenth_out<=0;
        hundred_out<=0;
    end
    else if(done4)begin
        thousand_out<=(uints3==1)?4'd9:multi3[3:0];
        tenth_out<=(uints3==1)?4'd9:tenth3;
        hundred_out<=(uints3==1)?4'd9:hundred3;
    end
end
endmodule

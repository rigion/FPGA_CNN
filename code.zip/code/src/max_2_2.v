// �Ե������ڱȴ�С
// �㷨���ֱ�ȽϷ���λ��ָ��5λ����β��λ������ȫ�Ƚ�
module max_2_2(
    input[15:0]a,
    input[15:0]b,
    input[15:0]c,
    input[15:0]d,
    input valid_in,
    input clk,
    input rst_n,
    output reg[3:0]led
);
    wire [5:0] check;
    wire done;
    // ʵ�����Ƚ���
    compare_2 com_AB(.A(a), .B(b),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[0]),.valid_out()); // a >= b
    compare_2 com_AC(.A(a), .B(c),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[1]),.valid_out(done)); // a >= c
    compare_2 com_AD(.A(a), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[2]),.valid_out()); // a >= d
    compare_2 com_BC(.A(b), .B(c),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[3]),.valid_out()); // b >= c
    compare_2 com_BD(.A(b), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[4]),.valid_out()); // b >= d
    compare_2 com_CD(.A(c), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[5]),.valid_out()); // c >= d
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)led<=0;
        else if(done)begin
            if (check[0] && check[1] && check[2]) begin
                led<=4'b0001;
        end else if (check[3] && check[4]) begin
                led<=4'b0010;
        end else if (check[5]) begin
                led<=4'b0100;
        end else begin
                led<=4'b1000;
        end
        end
    end
endmodule
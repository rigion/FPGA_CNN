module global_average(
    input clk,
    input valid_in,
    input [15:0]data_in,
    input rst_n,
    output valid_out,
    output[15:0]data_out
    );
localparam element_num = 5'd16;
localparam ele_num_FP16 =16'h4c00;
reg[3:0]cnt;
wire[15:0]acc_data;
wire acc_done;
reg last;
reg[15:0]data_dly;
reg valid_dly;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        cnt<=4'b1111;
        last<=0;
    end
    else if(valid_in)begin
        cnt<=cnt+1;//����Զ�����
        last<=(cnt==4'b1110);
    end
    else begin
        cnt<=cnt;
        last<=0;
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        valid_dly<=0;
        data_dly<=0;
    end
    else begin
        valid_dly<=valid_in;
        data_dly<=data_in;
    end
end
accumulator acc(
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(valid_dly),           
  .s_axis_a_tdata(data_dly),              
  .s_axis_a_tlast(last),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(acc_data),   
  .m_axis_result_tlast(acc_done)    
);
divide dvi(//   A/B
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(acc_done),            
  .s_axis_a_tdata(acc_data),              
  .s_axis_b_tvalid(acc_done),           
  .s_axis_b_tdata(ele_num_FP16),              
  .m_axis_result_tvalid(valid_out),  
  .m_axis_result_tdata(data_out)    
);
endmodule

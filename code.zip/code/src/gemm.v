module gemm(
    input valid_in,
    input clk,
    input rst_n,
    input[15:0]data_in,
    output[15:0]float_out1,
    output[15:0]float_out2,
    output[15:0]float_out3,
    output[15:0]float_out4,
    output valid_out
    );
reg[4:0]addr;
reg valid_dly1,valid_dly2,last,multi_valid_dly;
reg[15:0]data_dly1,data_dly2,multi_data_dly1,multi_data_dly2,multi_data_dly3,multi_data_dly4;
wire[15:0]multi_data1,multi_data2,multi_data3,multi_data4,rom_data1,rom_data2,rom_data3,rom_data4;
wire multi_valid,ac_valid;
wire[15:0]data_out1,data_out2,data_out3,data_out4;
reg[4:0]cnt;
localparam B1 = 16'ha9f2;
localparam B2 = 16'had4d;
localparam B3 = 16'h3802;
localparam B4 = 16'h2f53;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)addr<=5'd31; 
    else if(valid_in)addr<=(addr==5'd21)?0:addr+1;
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        valid_dly2<=0;
        valid_dly1<=0;
        data_dly1<=0;
        data_dly2<=0;
    end 
    else begin
        data_dly1<=data_in;
        data_dly2<=data_dly1;
        valid_dly2<=valid_dly1;
        valid_dly1<=valid_in;
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)begin
        cnt<=5'd31;
        // multi_data_dly<=0;
        {multi_data_dly1,multi_data_dly2,multi_data_dly3,multi_data_dly4}<=0;
        multi_valid_dly<=0;
    end
    else begin
        if(multi_valid)begin
            cnt<=(cnt==5'd21)?0:cnt+1;
            {multi_data_dly1,multi_data_dly2,multi_data_dly3,multi_data_dly4}<={multi_data1,multi_data2,multi_data3,multi_data4};
            multi_valid_dly<=multi_valid;
        end
        else begin
            {multi_data_dly1,multi_data_dly2,multi_data_dly3,multi_data_dly4}<=0;
            multi_valid_dly<=0;
        end 
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)last<=0;
    else if(cnt==5'd20&&multi_valid)last<=1;
    else last<=0;
end
ROM12 rom1(
  .clka(clk),    
  .addra({1'b0,addr}),  
  .douta(rom_data1),  
  .clkb(clk),    
  .addrb({1'b1,addr}),  
  .doutb(rom_data2)  
);
ROM34 rom2(
  .clka(clk),   
  .addra({1'b0,addr}),  
  .douta(rom_data3), 
  .clkb(clk),   
  .addrb({1'b1,addr}),  
  .doutb(rom_data4)  
);
multi mu1(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(valid_dly2),            
  .s_axis_a_tdata(data_dly2),              
  .s_axis_b_tvalid(valid_dly2),            
  .s_axis_b_tdata(rom_data1),              
  .m_axis_result_tvalid(multi_valid),  
  .m_axis_result_tdata(multi_data1)   
);
accumulator ac1(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(multi_valid_dly),           
  .s_axis_a_tdata(multi_data_dly1),            
  .s_axis_a_tlast(last),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(data_out1),    
  .m_axis_result_tlast(ac_valid)   
);
multi mu2(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(valid_dly2),            
  .s_axis_a_tdata(data_dly2),              
  .s_axis_b_tvalid(valid_dly2),            
  .s_axis_b_tdata(rom_data2),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(multi_data2)   
);
accumulator ac2(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(multi_valid_dly),           
  .s_axis_a_tdata(multi_data_dly2),            
  .s_axis_a_tlast(last),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(data_out2),    
  .m_axis_result_tlast()   
);
multi mu3(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(valid_dly2),            
  .s_axis_a_tdata(data_dly2),              
  .s_axis_b_tvalid(valid_dly2),            
  .s_axis_b_tdata(rom_data3),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(multi_data3)   
);
accumulator ac3(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(multi_valid_dly),           
  .s_axis_a_tdata(multi_data_dly3),            
  .s_axis_a_tlast(last),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(data_out3),    
  .m_axis_result_tlast()   
);
multi mu4(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(valid_dly2),            
  .s_axis_a_tdata(data_dly2),              
  .s_axis_b_tvalid(valid_dly2),            
  .s_axis_b_tdata(rom_data4),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(multi_data4)   
);
accumulator ac4(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(multi_valid_dly),           
  .s_axis_a_tdata(multi_data_dly4),            
  .s_axis_a_tlast(last),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(data_out4),    
  .m_axis_result_tlast()   
);
adder adder1(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(ac_valid),          
  .s_axis_a_tdata(data_out1),            
  .s_axis_b_tvalid(ac_valid),           
  .s_axis_b_tdata(B1),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(float_out1)    
);
adder adder2(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(ac_valid),          
  .s_axis_a_tdata(data_out2),            
  .s_axis_b_tvalid(ac_valid),           
  .s_axis_b_tdata(B2),              
  .m_axis_result_tvalid(valid_out),  
  .m_axis_result_tdata(float_out2)    
);
adder adder3(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(ac_valid),          
  .s_axis_a_tdata(data_out3),            
  .s_axis_b_tvalid(ac_valid),           
  .s_axis_b_tdata(B3),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(float_out3)    
);
adder adder4(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(ac_valid),          
  .s_axis_a_tdata(data_out4),            
  .s_axis_b_tvalid(ac_valid),           
  .s_axis_b_tdata(B4),              
  .m_axis_result_tvalid(),  
  .m_axis_result_tdata(float_out4)    
);
endmodule

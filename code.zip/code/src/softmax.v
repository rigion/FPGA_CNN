module softmax(
    input[15:0]float1,
    input[15:0]float2,
    input[15:0]float3,
    input[15:0]float4,
    input start,
    input clk,
    input rst_n,
    output[15:0]ans1,
    output[15:0]ans2,
    output[15:0]ans3,
    output[15:0]ans4,
    output done
    );
wire[15:0]float_exp1,float_exp2,float_exp3,float_exp4,float_adder1,float_adder2,float_adder3,float_recip,out1,out2,out3,out4;
reg[15:0]exp1_dly1,exp2_dly1,exp3_dly1,exp4_dly1;
reg[15:0]exp1_dly2,exp2_dly2,exp3_dly2,exp4_dly2;
reg[15:0]exp1_dly3,exp2_dly3,exp3_dly3,exp4_dly3;
reg[15:0]exp1_dly4,exp2_dly4,exp3_dly4,exp4_dly4;
reg[15:0]exp1_dly5,exp2_dly5,exp3_dly5,exp4_dly5;
reg[15:0]exp1_dly6,exp2_dly6,exp3_dly6,exp4_dly6;
reg[15:0]exp1_dly7,exp2_dly7,exp3_dly7,exp4_dly7;
reg[15:0]exp1_dly8,exp2_dly8,exp3_dly8,exp4_dly8;
wire exp_done1,exp_done2,exp_done3,exp_done4,adder_done1,adder_done2,adder_done3,recip_done;
wire done1,done2,done3,done4;
assign done=done1;
always @(posedge clk or negedge rst_n) begin
  if(!rst_n)begin
    {exp1_dly1,exp2_dly1,exp3_dly1,exp4_dly1}<=0;
    {exp1_dly2,exp2_dly2,exp3_dly2,exp4_dly2}<=0;
    {exp1_dly3,exp2_dly3,exp3_dly3,exp4_dly3}<=0;
    {exp1_dly4,exp2_dly4,exp3_dly4,exp4_dly4}<=0;
    {exp1_dly5,exp2_dly5,exp3_dly5,exp4_dly5}<=0;
    {exp1_dly6,exp2_dly6,exp3_dly6,exp4_dly6}<=0;
    {exp1_dly7,exp2_dly7,exp3_dly7,exp4_dly7}<=0;
    {exp1_dly8,exp2_dly8,exp3_dly8,exp4_dly8}<=0;
  end
  else begin
    exp1_dly1<=float_exp1;
    exp1_dly2<=exp1_dly1;
    exp1_dly3<=exp1_dly2;
    exp1_dly4<=exp1_dly3;
    exp1_dly5<=exp1_dly4;
    exp1_dly6<=exp1_dly5;
    exp1_dly7<=exp1_dly6;
    exp1_dly8<=exp1_dly7;

    exp2_dly1<=float_exp2;
    exp2_dly2<=exp2_dly1;
    exp2_dly3<=exp2_dly2;
    exp2_dly4<=exp2_dly3;
    exp2_dly5<=exp2_dly4;
    exp2_dly6<=exp2_dly5;
    exp2_dly7<=exp2_dly6;
    exp2_dly8<=exp2_dly7;

    exp3_dly1<=float_exp3;
    exp3_dly2<=exp3_dly1;
    exp3_dly3<=exp3_dly2;
    exp3_dly4<=exp3_dly3;
    exp3_dly5<=exp3_dly4;
    exp3_dly6<=exp3_dly5;
    exp3_dly7<=exp3_dly6;
    exp3_dly8<=exp3_dly7;

    exp4_dly1<=float_exp4;
    exp4_dly2<=exp4_dly1;
    exp4_dly3<=exp4_dly2;
    exp4_dly4<=exp4_dly3;
    exp4_dly5<=exp4_dly4;
    exp4_dly6<=exp4_dly5;
    exp4_dly7<=exp4_dly6;
    exp4_dly8<=exp4_dly7;
  end
end
floating_point_0 exp1(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(start),            
  .s_axis_a_tdata(float1),             
  .m_axis_result_tvalid(exp_done1),  
  .m_axis_result_tdata(float_exp1)    
);
floating_point_0 exp2(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(start),            
  .s_axis_a_tdata(float2),             
  .m_axis_result_tvalid(exp_done2),  
  .m_axis_result_tdata(float_exp2)    
);
floating_point_0 exp3(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(start),            
  .s_axis_a_tdata(float3),             
  .m_axis_result_tvalid(exp_done3),  
  .m_axis_result_tdata(float_exp3)    
);
floating_point_0 exp4(
  .aclk(clk),                                  
  .aresetn(rst_n),                           
  .s_axis_a_tvalid(start),            
  .s_axis_a_tdata(float4),             
  .m_axis_result_tvalid(exp_done4),  
  .m_axis_result_tdata(float_exp4)    
);
adder adder1(
  .aclk(clk),                                 
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(exp_done1),            
  .s_axis_a_tdata(float_exp1),              
  .s_axis_b_tvalid(exp_done2),            
  .s_axis_b_tdata(float_exp2),              
  .m_axis_result_tvalid(adder_done1),  
  .m_axis_result_tdata(float_adder1)    
);
adder adder2(
  .aclk(clk),                                 
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(exp_done3),            
  .s_axis_a_tdata(float_exp3),              
  .s_axis_b_tvalid(exp_done4),            
  .s_axis_b_tdata(float_exp4),              
  .m_axis_result_tvalid(adder_done2),  
  .m_axis_result_tdata(float_adder2)    
);
adder adder3(
  .aclk(clk),                                 
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(adder_done2),            
  .s_axis_a_tdata(float_adder2),              
  .s_axis_b_tvalid(adder_done1),            
  .s_axis_b_tdata(float_adder1),              
  .m_axis_result_tvalid(adder_done3),  
  .m_axis_result_tdata(float_adder3)    
);
divide dvi1(//   A/B
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(adder_done3),            
  .s_axis_a_tdata(exp1_dly8),              
  .s_axis_b_tvalid(adder_done3),           
  .s_axis_b_tdata(float_adder3),              
  .m_axis_result_tvalid(done1),  
  .m_axis_result_tdata(out1)    
);
divide dvi2(//   A/B
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(adder_done3),            
  .s_axis_a_tdata(exp2_dly8),              
  .s_axis_b_tvalid(adder_done3),           
  .s_axis_b_tdata(float_adder3),              
  .m_axis_result_tvalid(done2),  
  .m_axis_result_tdata(out2)    
);
divide dvi3(//   A/B
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(adder_done3),            
  .s_axis_a_tdata(exp3_dly8),              
  .s_axis_b_tvalid(adder_done3),           
  .s_axis_b_tdata(float_adder3),              
  .m_axis_result_tvalid(done3),  
  .m_axis_result_tdata(out3)    
);
divide dvi4(//   A/B
  .aclk(clk),                                  
  .aresetn(rst_n),                            
  .s_axis_a_tvalid(adder_done3),            
  .s_axis_a_tdata(exp4_dly8),              
  .s_axis_b_tvalid(adder_done3),           
  .s_axis_b_tdata(float_adder3),              
  .m_axis_result_tvalid(done4),  
  .m_axis_result_tdata(out4)    
);
assign ans1=(done1)?out1:0;
assign ans2=(done2)?out2:0;
assign ans3=(done3)?out3:0;
assign ans4=(done4)?out4:0;
endmodule

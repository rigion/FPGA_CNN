`timescale 1ns/1ps
`define COE_FILE "C:/Users/kangk/Desktop/cnn_data/dump_glioma_1_fp16/input.coe"
`define SEND_HIGH_FIRST 1   // 1: ���ֽ��ȷ���0: ���ֽ��ȷ�

module tb_UART_RAM_TFT_CNN;

  // ===== ʱ��/��λ =====
  reg Clk = 1'b0;
  always #10 Clk = ~Clk;   // 50 MHz
  reg Reset_n = 1'b0;
  initial begin
    Reset_n = 1'b0;
    repeat (20) @(posedge Clk);
    Reset_n = 1'b1;
  end

  // ===== UART �� =====
  reg uart_rx = 1'b1;      // ����Ϊ��

  // ===== DUT �˿� =====
  wire [15:0] VGA_RGB;
  wire        VGA_HS, VGA_VS, VGA_BLK, VGA_CLK, TFT_BL;
  wire        cnn_valid;
  wire [15:0] cnn_fp16;
  wire [15:0] cnn_addr;

  // ===== DUT ʵ�� =====
  UART_RAM_TFT_CNN dut (
    .Clk      (Clk),
    .Reset_n  (Reset_n),
    .uart_rx  (uart_rx),
    .VGA_RGB  (VGA_RGB),
    .VGA_HS   (VGA_HS),
    .VGA_VS   (VGA_VS),
    .VGA_BLK  (VGA_BLK),
    .VGA_CLK  (VGA_CLK),
    .TFT_BL   (TFT_BL),
    .cnn_valid(cnn_valid),
    .cnn_fp16 (cnn_fp16),
    .cnn_addr (cnn_addr)
  );

  // ====== �������� ======
  // 256x256 ���أ�16bit ÿ���أ�RGB565��
  localparam IMG_W  = 256;
  localparam IMG_H  = 256;
  localparam NPIX   = IMG_W*IMG_H;   // 65536
  localparam CLK_HZ = 50_000_000;
  localparam BAUD   = 115200;
  localparam BIT_CYC= CLK_HZ/BAUD;   // ��434

  // ====== �� COE ������ ======
  reg [15:0] pix_mem [0:NPIX-1];
  integer i;

  initial begin
    $timeformat(-9, 3, " ns", 10);
    $display("[TB] $readmemh from %s ...", `COE_FILE);
    // ע�⣺���������޷����� .coe ͷ���������ֻ��ʮ���������� .mem �ļ�
    $readmemh(`COE_FILE, pix_mem);
    $display("[TB] load done. first 4 = %h %h %h %h",
             pix_mem[0], pix_mem[1], pix_mem[2], pix_mem[3]);

    // �ȸ�λ�ȶ�
    @(posedge Reset_n);
    repeat(50) @(posedge Clk);

    // ͨ�� UART �����ط��ͣ�16bit һ�����أ�
    $display("[TB] start UART streaming %0d pixels ...", NPIX);
    for (i=0; i<NPIX; i=i+1) begin
      uart_send_word16(pix_mem[i]);
      // �ʶȿ���
      repeat(2) @(posedge Clk);
    end
    $display("[TB] UART streaming done.");

    // �ȴ���ˮ����
    repeat(50000) @(posedge Clk);
    $display("[TB] finish.");
    $finish;
  end

  // ===== UART ��������8N1, LSB-first��=====
  task uart_send_byte;
    input [7:0] b;
    integer k;
    begin
      // start bit
      uart_rx <= 1'b0;
      repeat(BIT_CYC) @(posedge Clk);
      // data bits LSB-first
      for (k=0; k<8; k=k+1) begin
        uart_rx <= b[k];
        repeat(BIT_CYC) @(posedge Clk);
      end
      // stop bit
      uart_rx <= 1'b1;
      repeat(BIT_CYC) @(posedge Clk);
    end
  endtask

  task uart_send_word16;
    input [15:0] w;
    begin
      if (`SEND_HIGH_FIRST) begin
        uart_send_byte(w[15:8]);
        uart_send_byte(w[7:0]);
      end else begin
        uart_send_byte(w[7:0]);
        uart_send_byte(w[15:8]);
      end
    end
  endtask

  // ===== �����¼ =====
  integer f_out;
  initial begin
    f_out = $fopen("pool2_norm_fp16.txt", "w");
    if (f_out == 0) $display("[TB] ERROR: cannot open output file.");
  end

  // FP16 -> real��������۲��ã�
  function real fp16_to_real;
    input [15:0] h;
    reg s;
    reg [4:0] eh;
    reg [9:0] mh;
    real rr;
    begin
      s  = h[15];
      eh = h[14:10];
      mh = h[9:0];
      if (eh==5'd0) begin
        if (mh==10'd0) rr = 0.0;
        else rr = (s ? -1.0 : 1.0) * (mh/1024.0) * (2.0**(-14));
      end else if (eh==5'd31) begin
        rr = 1.0/0.0;  // INF/NaN�������õ���
      end else begin
        rr = (s ? -1.0 : 1.0) * (2.0**(eh-15)) * (1.0 + mh/1024.0);
      end
      fp16_to_real = rr;
    end
  endfunction

  integer shown;
  initial shown = 0;

  always @(posedge Clk) begin
    if (cnn_valid) begin
      if (shown < 20) begin
        $display("[%0t] addr=%0d  fp16=0x%04h  val=%f",
                 $time, cnn_addr, cnn_fp16, fp16_to_real(cnn_fp16));
        shown = shown + 1;
      end
      $fdisplay(f_out, "%0d %04h %f", cnn_addr, cnn_fp16, fp16_to_real(cnn_fp16));
    end
  end

endmodule

// ---- MMCM ����׮��clk ֱͨ��----
module MMCM(input clk_in1, output clk_out1);
  assign clk_out1 = clk_in1;
endmodule

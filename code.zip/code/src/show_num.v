module show_num(
    input clk,
    input[3:0]num0,
    input[3:0]num1,
    input[3:0]num2,
    input[3:0]num3,
    input[1:0]cnt,
    input[8:0]addr,     
    output num_data
    );
wire[15:0]rom_data;
reg[3:0]col_reg;     
reg[3:0]num_reg;   
reg[4:0]row_index;  
reg[3:0]col_index;

number rom(
  .clka(clk),   
  .addra({num_reg,row_index}),  
  .douta(rom_data)  
);
always @(posedge clk) begin
    row_index<=addr[8:4];//addr/16ȡ��
    col_index<=15-addr[3:0];//15-addr%16
    case(cnt)
    2'b00:num_reg<=num0;
    2'b01:num_reg<=num1;
    2'b10:num_reg<=num2;
    2'b11:num_reg<=num3;
    default:num_reg<=0;
    endcase
    col_reg  <= col_index;
end
assign num_data=rom_data[col_reg];
endmodule
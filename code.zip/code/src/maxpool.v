module maxpool#(parameter width = 256)(
    input clk,
    input rst_n,
    
    input valid_in,
    input [15:0]data_in,
    output en_out,
    output[15:0]data_max
    );
wire[15:0]data_out1,data_out2,data_out3,data_out4;
wire valid_out;

window#(.picture_width(width))
win(
    .valid_in(valid_in),
    .data_in(data_in),
    .clk(clk),
    .rst_n(rst_n),
    .valid_out(valid_out),
    .data_out1(data_out1),
    .data_out2(data_out2),
    .data_out3(data_out3),
    .data_out4(data_out4)
    );
max_2_2 max(
    .a(data_out1),
    .b(data_out2),
    .c(data_out3),
    .d(data_out4),
    .valid_in(valid_out),
    .clk(clk),
    .rst_n(rst_n),
    .data_out(data_max),
    .done(en_out)
);
endmodule

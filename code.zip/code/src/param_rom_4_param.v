
`timescale      1ns/1ns

module  param_rom_4_param
#(      
        parameter   PARAM_RD_ADDR_NUM =     10,
		parameter   CONV_NUM          =      5
)       
        
(
        // system signals
        input                   clk                     ,       
        input                   rst_n                   ,       
        // 
        input           [ PARAM_RD_ADDR_NUM-1:0]  param_rd_addr         ,//��������ַ
        input           [ CONV_NUM      -1:0]     conv_cnt             ,//����ͼ������������ƫ�ö�ȡ
        output  wire    [15:0]  param_w_h0              ,
        output  wire    [15:0]  param_w_h1              ,
        output  wire    [15:0]  param_w_h2              ,
        output  wire    [15:0]  param_bias                    
);

//========================================================================\
// =========== Define Parameter and Internal signals =========== 
//========================================================================/



//=============================================================================
//**************    Main Code   **************
//=============================================================================
rom_4_b_ip        rom_3_b_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .addra                  (conv_cnt              ),  // input wire [4 : 0] addra
        .douta                  (param_bias            )// output wire [15 : 0] douta
);

rom_4_w0_ip       rom_3_w0_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h0             )// output wire [15 : 0] douta
);

rom_4_w1_ip       rom_3_w1_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h1             )// output wire [15 : 0] douta
);

rom_4_w2_ip       rom_3_w2_ip_inst (
        .clka                   (clk                   ),    // input wire clka
        .addra                  (param_rd_addr          ),  // input wire [7 : 0] addra
        .douta                  (param_w_h2             )// output wire [15 : 0] douta
);
endmodule

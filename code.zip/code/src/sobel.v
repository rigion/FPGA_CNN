module sobel
(
  input                      clk,    //pixel clk
  input                      rst_n,
  input                [7:0] data_in,
  input                [15:0]addr_in,
  input                      data_in_valid,
  input                      data_in_hs,
  input                      data_in_vs,

  output reg[6:0]            data_out,
  output reg[15:0]           addr_out,
  output reg                 data_out_valid
);
reg[5:0]data_dly1,data_dly2;
reg[15:0]addr_dly1,addr_dly2;
//line data
wire [7:0] line0_data;
wire [7:0] line1_data;
wire [7:0] line2_data;
//matrix 3x3 data
reg  [7:0] row0_col0;
reg  [7:0] row0_col1;
reg  [7:0] row0_col2;

reg  [7:0] row1_col0;
reg  [7:0] row1_col1;
reg  [7:0] row1_col2;

reg  [7:0] row2_col0;
reg  [7:0] row2_col1;
reg  [7:0] row2_col2;

reg   data_in_valid_dly1;
reg   data_in_valid_dly2;
reg   data_in_hs_dly1;
reg   data_in_hs_dly2;
reg   data_in_vs_dly1;
reg   data_in_vs_dly2;

wire  Gx_is_positive;
wire  Gy_is_positive;

reg  [9:0] Gx_absolute; //high bit expansion 2bit
reg  [9:0] Gy_absolute; //high bit expansion 2bit

shift_reg_ram shift_reg_ram_inst1 (
  .D   (data_in       ),// input wire [7 : 0] D
  .CLK (clk           ),// input wire CLK
  .CE  (data_in_valid ),// input wire CE
  .Q   (line1_data    ) // output wire [7 : 0] Q
);

shift_reg_ram shift_reg_ram_inst2 (
  .D  (line1_data    ),// input wire [7 : 0] D
  .CLK(clk           ),// input wire CLK
  .CE (data_in_valid ),// input wire CE
  .Q  (line0_data    ) // output wire [7 : 0] Q
);
assign line2_data = data_in;

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
    row0_col0 <= 'd0;
    row0_col1 <= 'd0;
    row0_col2 <= 'd0;

    row1_col0 <= 'd0;
    row1_col1 <= 'd0;
    row1_col2 <= 'd0;

    row2_col0 <= 'd0;
    row2_col1 <= 'd0;
    row2_col2 <= 'd0;
  end
  else if(data_in_hs && data_in_vs)
    if(data_in_valid) begin
      row0_col2 <= line0_data;
      row0_col1 <= row0_col2;
      row0_col0 <= row0_col1;

      row1_col2 <= line1_data;
      row1_col1 <= row1_col2;
      row1_col0 <= row1_col1;

      row2_col2 <= line2_data;
      row2_col1 <= row2_col2;
      row2_col0 <= row2_col1;
    end
    else begin
      row0_col2 <= row0_col2;
      row0_col1 <= row0_col1;
      row0_col0 <= row0_col0;

      row1_col2 <= row1_col2;
      row1_col1 <= row1_col1;
      row1_col0 <= row1_col0;

      row2_col2 <= row2_col2;
      row2_col1 <= row2_col1;
      row2_col0 <= row2_col0;
    end
  else begin
    row0_col0 <= 'd0;
    row0_col1 <= 'd0;
    row0_col2 <= 'd0;

    row1_col0 <= 'd0;
    row1_col1 <= 'd0;
    row1_col2 <= 'd0;

    row2_col0 <= 'd0;
    row2_col1 <= 'd0;
    row2_col2 <= 'd0;
  end
end

always @(posedge clk)
if(!rst_n)begin
  data_in_hs_dly1<=0;
  data_in_hs_dly2<=0;
  data_in_vs_dly1<=0;
  data_in_vs_dly2<=0;
  data_in_valid_dly1<=0;
  data_in_valid_dly2<=0;
  data_out_valid<=0;
  data_dly1<=6'b0;
  data_dly2<=6'b0;
  addr_dly1<=16'b0;
  addr_dly2<=16'b0;
end
else begin
  data_in_valid_dly1 <= data_in_valid;
  data_in_valid_dly2 <= data_in_valid_dly1;
  data_out_valid <= data_in_valid_dly2;

  data_in_hs_dly1    <= data_in_hs;
  data_in_hs_dly2    <= data_in_hs_dly1;

  data_in_vs_dly1    <= data_in_vs;
  data_in_vs_dly2    <= data_in_vs_dly1;
   
  data_dly1<=data_in[7:3];
  data_dly2<=data_dly1;

  addr_dly1<=addr_in;
  addr_dly2<=addr_dly1;
  addr_out<=addr_dly2;
end

assign Gx_is_positive = (row0_col2 + row1_col2*2 + row2_col2) >= (row0_col0 + row1_col0*2 + row2_col0);
assign Gy_is_positive = (row0_col0 + row0_col1*2 + row0_col2) >= (row2_col0 + row2_col1*2 + row2_col2);

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) 
    Gx_absolute <= 'd0;
  else if(data_in_valid_dly1) begin
    if(Gx_is_positive)
      Gx_absolute <= (row0_col2 + row1_col2*2 + row2_col2) - (row0_col0 + row1_col0*2 + row2_col0);
    else
      Gx_absolute <= (row0_col0 + row1_col0*2 + row2_col0) - (row0_col2 + row1_col2*2 + row2_col2);
  end
end

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) 
    Gy_absolute <= 'd0;
  else if(data_in_valid_dly1) begin
    if(Gy_is_positive)
      Gy_absolute <= (row0_col0 + row0_col1*2 + row0_col2) - (row2_col0 + row2_col1*2 + row2_col2);
    else
      Gy_absolute <= (row2_col0 + row2_col1*2 + row2_col2) - (row0_col0 + row0_col1*2 + row0_col2);
  end
end

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) 
    data_out <= 6'b0;
  else if(data_in_valid_dly2) begin
    data_out <= ((Gx_absolute+Gy_absolute)>7'b1000000) ? {data_dly2,1'b0} : {data_dly2,1'b1};//��ֵ����
  end
end

endmodule 
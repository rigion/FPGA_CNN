module  fifo_ctrl_4_param
#(
        //���� 
		parameter   OUTPUT_SIZE    =   16 ,
		parameter   FEATURE_NUM    =   14 ,
		parameter   CONV_NUM       =   18 ,
        //������
        parameter   COL_CNT_NUM     =   6 ,
		parameter   ROW_CNT_NUM     =   5 ,
		parameter   FEATURE_CNT_NUM =   4 ,
		parameter   CONV_CNT_NUM    =   4
)
(
        // system singals
        input                      Clk              ,       
        input                      rst_n            ,       
        // paddingsample           
        input           [15:0]     conv_rslt        ,//�����������,����34*34*10       
        input                      conv_rslt_vld    ,//�������ʹ��
        input           [ COL_CNT_NUM-1:0]     col_cnt          ,//�����м�����
        input           [ ROW_CNT_NUM-1:0]     row_cnt          ,//�����м�����
		//����ͨ������ 
		input           [ CONV_CNT_NUM    -1:0]     conv_cnt         ,//�����˼�����
		input           [ FEATURE_CNT_NUM -1:0]     feature_cnt      ,//����ͼ������
		// ƫ�ü���ģ��ӿ�
        input                      rd_en            ,//fifo��ʹ��
        //���
        output     wire [15:0]     rd_data [FEATURE_NUM -1:0]    ,//��������
        output     reg             cal_start         //�洢������־������ʹ�ܣ�          
);

//========================================================================\
// =========== Define Parameter and Internal signals =========== 
//========================================================================/

reg     [FEATURE_NUM-1:0]                  wr_en  ; //ʹ���źţ�ÿ��FIFOʹ��һ��      
//=============================================================================
//**************    Main Code   **************
//=============================================================================

integer i;
always  @(*) begin
        for(i=0; i<= FEATURE_NUM - 1'd1; i=i+1) begin   //����ʹ���ź�
                if(feature_cnt == i)
                        wr_en[i]        =       conv_rslt_vld;  //���������Ӧ�е�ʹ���ø�
                else
                        wr_en[i]        =       1'b0;
        end
end

always  @(posedge Clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                cal_start       <=      1'b0;
        else if(col_cnt == OUTPUT_SIZE + 3'd5 && row_cnt == OUTPUT_SIZE - 1'd1 && conv_cnt == CONV_NUM - 1'd1 && feature_cnt == FEATURE_NUM - 1'd1)
                cal_start       <=      1'b1;
        else
                cal_start       <=      1'b0;
end


generate
    genvar k;
    for (k = 0; k <= FEATURE_NUM - 1'd1; k = k + 1) begin : fifo_inst_loop
        conv_4_fifo  conv_4_fifo_inst (                      
            .clk(Clk),          // input wire clk
            .srst(~rst_n),      // input wire srst
            .din(conv_rslt),    // input wire [15 : 0] din
            .wr_en(wr_en[k]),   // input wire wr_en
            .rd_en(rd_en),      // input wire rd_en
            .dout(rd_data[k]),  // output wire [15 : 0] dout
            .full(),            // output wire full
            .empty()            // output wire empty
        );
    end
endgenerate


endmodule


// �Ե������ڱȴ�С
// �㷨���ֱ�ȽϷ���λ��ָ��5λ����β��λ������ȫ�Ƚ�
module max_2_2(
    input[15:0]a,
    input[15:0]b,
    input[15:0]c,
    input[15:0]d,
    input valid_in,
    input clk,
    input rst_n,
    output reg[15:0]data_out,
    output reg done
);
    wire [15:0] a, b, c, d;
    reg[15:0]a_reg,b_reg,c_reg,d_reg;
    wire [5:0] check;
    wire valid_out;
    // ʵ�����Ƚ���
    compare_2 com_AB(.A(a), .B(b),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[0]),.valid_out()); // a >= b
    compare_2 com_AC(.A(a), .B(c),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[1]),.valid_out(valid_out)); // a >= c
    compare_2 com_AD(.A(a), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[2]),.valid_out()); // a >= d
    compare_2 com_BC(.A(b), .B(c),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[3]),.valid_out()); // b >= c
    compare_2 com_BD(.A(b), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[4]),.valid_out()); // b >= d
    compare_2 com_CD(.A(c), .B(d),.valid_in(valid_in), .clk(clk), .rst_n(rst_n), .check(check[5]),.valid_out()); // c >= d
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_reg<=0;
            b_reg<=0;
            c_reg<=0;
            d_reg<=0;
        end else begin
            a_reg<=a;
            b_reg<=b;
            c_reg<=c;
            d_reg<=d;
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)begin
            data_out<=0;
            done<=0;
        end
        else begin
            done<=valid_out;
            if (check[0] && check[1] && check[2]) begin
            data_out = a_reg;
        end else if (check[3] && check[4]) begin
            data_out = b_reg;
        end else if (check[5]) begin
            data_out = c_reg;
        end else begin
            data_out = d_reg;
        end
        end
    end
endmodule
`timescale 1ns / 1ps

module cacl_ctrl_2(
    input      clk  ,
	input      rst_n,
	
	//fifo_ctrl���ݽӿ�
	input     wire  [15:0]   rd_data [9:0],//�������������
	input                    cal_start    ,//����ʹ��
	output                   rd_en        ,//��ʹ��
	//ƫ��rom�ӿ�
	input           [15:0]   param_data   ,//ƫ������
 	output    reg    [3:0]   conv_cnt     ,//ƫ�ö���ַ 
	//�������
	output       [15:0]      conv_act_rslt     ,//relu���
	output    reg            conv_act_vld  //���ʹ��
    );
//*******************��������****************************
reg               cacl_flag;
reg     [5:0]     col_cnt;//�м�����
reg     [5:0]     row_cnt;//�м�����
wire    [15:0]    sum;
reg     [15:0]    conv_act;

wire              result_valid;

//*******************Main code*****************************
//��ʹ��
assign  rd_en = cacl_flag;

//������־�źŶ���
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                cacl_flag       <=      1'b0;                             
        else if(conv_cnt == 'd14 && row_cnt == 'd31 && col_cnt == 'd31)//�������
                cacl_flag       <=      1'b0;
        else if(cal_start == 1'b1)
                cacl_flag       <=      1'b1;
end
//�м�������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                row_cnt <=      'd0;
        else if(row_cnt == 'd31 && cacl_flag == 1'b1 && col_cnt == 'd31)//һ�������˼�����ɺ���0
                row_cnt <=      'd0;
        else if(cacl_flag == 1'b1 && col_cnt == 'd31)
                row_cnt <=      row_cnt + 1'b1;
end
//�м�������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                col_cnt    <=      'd0;
        else if(cacl_flag == 1'b1 && col_cnt == 'd31)
                col_cnt    <=      'd0;
        else if(cacl_flag == 1'b1)
                col_cnt    <=      col_cnt + 1'b1;
end
//�����˼���������
always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_cnt     <=      'd0;
		else if(cacl_flag == 1'b0)
                conv_cnt     <=      'd0;	
        else if(cacl_flag == 1'b1 && row_cnt == 'd31 && col_cnt == 'd30)
                conv_cnt     <=      conv_cnt + 1'b1;
end

float16_11sum #(
    .DATA_WIDTH(16)
) u_float16_11sum (
    .aclk(clk),
    .aresetn(rst_n),
    .data_in_0(rd_data[0]),
    .valid_in_0(cacl_flag),
    .data_in_1(rd_data[1]),
    .valid_in_1(cacl_flag),
    .data_in_2(rd_data[2]),
    .valid_in_2(cacl_flag),
    .data_in_3(rd_data[3]),
    .valid_in_3(cacl_flag),
    .data_in_4(rd_data[4]),
    .valid_in_4(cacl_flag),
    .data_in_5(rd_data[5]),
    .valid_in_5(cacl_flag),
    .data_in_6(rd_data[6]),
    .valid_in_6(cacl_flag),
    .data_in_7(rd_data[7]),
    .valid_in_7(cacl_flag),
    .data_in_8(rd_data[8]),
    .valid_in_8(cacl_flag),
    .data_in_9(rd_data[9]),
    .valid_in_9(cacl_flag),
	.data_in_10(param_data),
    .valid_in_10(cacl_flag),
    .sum_result(sum),
    .result_valid(result_valid)
);

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_act       <=      'd0;
        else if(result_valid == 1)
                conv_act       <=      sum;
end

always  @(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0)
                conv_act_vld       <=      1'b0;
        else 
		        conv_act_vld       <=      result_valid;
end

assign  conv_act_rslt = (conv_act[15] == 1'b0) ? conv_act : 'd0;

endmodule

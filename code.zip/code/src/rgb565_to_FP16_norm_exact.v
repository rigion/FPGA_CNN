`timescale 1ns/1ps
module rgb565_to_FP16_norm_exact
(
    input         clk,
    input         rst_n,       // ����Ч
    input         valid_i,
    input [15:0]  rgb565_i,    // {R[15:11],G[10:5],B[4:0]}
    output reg    valid_o,
    output reg [15:0] fp16_o   // IEEE-754 binary16, RNE
);
    // --------- S0: ���� + 565��888���ع�λ��---------
    reg        v0;
    reg [7:0]  R8, G8, B8;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            v0 <= 1'b0;
            R8 <= 8'd0; G8 <= 8'd0; B8 <= 8'd0;
        end else begin
            v0 <= valid_i;
            if (valid_i) begin
                // �� 565
                // �ع�λ��չ��R8={r5,r5[4:2]}��G8={g6,g6[5:4]}��B8={b5,b5[4:2]}
                R8 <= {rgb565_i[15:11], rgb565_i[15:13]};
                G8 <= {rgb565_i[10:5],  rgb565_i[10:9]};
                B8 <= {rgb565_i[4:0],   rgb565_i[4:2]};
            end
        end
    end

    // --------- S1: ���� N = 598R + 1174G + 228B - 255000 ---------
    // R/G/B ���255���������152,490 / 299,370 / 58,140���ܺ� �� 510,000
    // N �� [-255000, +255000]���ô����� 20~21 λ����
    reg        v1;
    reg  signed [20:0] N;            // �㹻���Ƿ�Χ
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            v1 <= 1'b0;
            N  <= 21'sd0;
        end else begin
            v1 <= v0;
            // �����˷������ۺ���ʵ�֣����� DSP��
            N  <= ( $signed({1'b0,R8}) * 11'sd598 )
                + ( $signed({1'b0,G8}) * 11'sd1174 )
                + ( $signed({1'b0,B8}) * 10'sd228 )
                - 21'sd255000;
        end
    end

    // --------- S2: N/255000 ֱ�Ӵ�� FP16��RNE�� ---------
    // �Ȱ� |N|*32768 / 255000 ��"�ͽ�ż��"ȡ�����õ� Q1.15 �ķ�ֵ��
    // �ٰ� Q1.15 ���Ϊ FP16��RNE����Q1.15 �ֱ���Զϸ�� FP16 LSB�����������������
    function [4:0] msb_index16;
        input [15:0] x;
        begin
            casex (x)
            16'b1??????????????? : msb_index16 = 5'd15;
            16'b01?????????????? : msb_index16 = 5'd14;
            16'b001????????????? : msb_index16 = 5'd13;
            16'b0001???????????? : msb_index16 = 5'd12;
            16'b00001??????????? : msb_index16 = 5'd11;
            16'b000001?????????? : msb_index16 = 5'd10;
            16'b0000001????????? : msb_index16 = 5'd9;
            16'b00000001???????? : msb_index16 = 5'd8;
            16'b000000001??????? : msb_index16 = 5'd7;
            16'b0000000001?????? : msb_index16 = 5'd6;
            16'b00000000001????? : msb_index16 = 5'd5;
            16'b000000000001???? : msb_index16 = 5'd4;
            16'b0000000000001??? : msb_index16 = 5'd3;
            16'b00000000000001?? : msb_index16 = 5'd2;
            16'b000000000000001? : msb_index16 = 5'd1;
            default              : msb_index16 = 5'd0;
            endcase
        end
    endfunction

    reg        v2;
    reg [15:0] out_half;

    always @(posedge clk or negedge rst_n) begin : S2
        // ����
        integer DEN;   // 255000
        begin end
        if (!rst_n) begin
            v2       <= 1'b0;
            out_half <= 16'h0000;
        end else begin
            v2 <= v1;

            // ������ֵ
            // �ñ�����Ϊ��һЩ�ۺ����ڳ��������ϵ��Ѻ�ʵ�֣����ǳ�����
            DEN = 255000;

            // 1) ȡ�������ֵ
            //    |N| ��� 255000
            //    A = |N| * 32768������ 15�����Լ 8.36e9���� 34~35 λ��
            //    �� A/DEN ��"�ͽ�ż��"ȡ�����õ� q �� [0..32768]
            //    Ȼ������ų�Ϊ Q1.15
            begin : Q15_ROUND
                reg        s;
                reg signed [20:0] N_s;
                reg [20:0] magN;
                reg [35:0] A;           // |N|<<15
                reg [16:0] q;           // 0..32768
                reg [35:0] prod;        // q*DEN
                reg [18:0] r2;          // 2*remainder��DEN<2^18��

                reg signed [15:0] q15;  // ������ Q1.15

                reg        sgn;
                reg [15:0] mag16;
                reg [4:0]  I, expf;
                reg [15:0] norm;
                reg [9:0]  mant;
                reg        guard, roundb, sticky;

                N_s = N;
                s   = N_s[20];
                magN= s ? ( (~N_s)+21'sd1 ) : N_s;

                A   = {magN,15'b0}; // *32768
                // �̣����㣩
                q   = A / DEN;
                // ����
                prod= q * DEN;
                r2  = (A - prod) << 1;

                // RNE��2*r > DEN �� (== �� q Ϊ��) -> q+1
                if ( (r2 > DEN[18:0]) || ((r2 == DEN[18:0]) && q[0]) )
                    q = q + 17'd1;

                // ���͵� Q1.15
                if (s) begin
                    if (q >= 17'd32768) q15 = -16'sd32768;
                    else                q15 = -$signed({1'b0,q[15:0]});
                end else begin
                    if (q >= 17'd32768) q15 =  16'sd32767; // +1.0 �� Q1.15 ��ʾΪ 0x7FFF
                    else                q15 =  $signed({1'b0,q[15:0]});
                end

                // 2) Q1.15 -> half (RNE)
                sgn   = q15[15];
                mag16 = sgn ? ( (q15==16'sh8000) ? 16'd32768 : (~q15 + 16'd1) )
                            : q15;

                if (q15==16'sd0) begin
                    out_half <= {sgn,15'd0};                    // ��0
                end else if (mag16 >= 16'd32768) begin
                    out_half <= {sgn, 5'd15, 10'd0};            // ��1.0
                end else if (mag16 == 16'd1) begin
                    out_half <= {sgn, 5'd0, 10'd512};           // ��С������
                end else begin
                    // ��񻯵� bit15=1
                    I    = msb_index16({1'b0,mag16[14:0]});     // 1..14
                    norm = mag16 << (15 - I);

                    mant   = norm[14:5];
                    guard  = norm[4];
                    roundb = norm[3];
                    sticky = |norm[2:0];

                    if (guard && (roundb | sticky | mant[0])) begin
                        mant = mant + 10'd1;
                        if (mant==10'd1024) begin
                            mant = 10'd0;
                            if (I==5'd14) out_half <= {sgn,5'd15,10'd0}; // ��λ��1.0
                            else          out_half <= {sgn,(I+5'd1),mant};
                        end else begin
                            out_half <= {sgn,I,mant};
                        end
                    end else begin
                        out_half <= {sgn,I,mant};
                    end
                end
            end
        end
    end

    // --------- ����Ĵ� ---------
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin valid_o<=1'b0; fp16_o<=16'h0000; end
        else begin valid_o<=v2;  fp16_o<=out_half; end
    end
endmodule
